package END_PROJCT;


import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.SwingUtilities;
import java.awt.Color;
import java.awt.Font;
import java.awt.Label;

import javax.swing.JTextField;
public class anewupdate extends JFrame {

    private JLabel jLabel;
    private JLabel jLabel1;
    public JFrame frame;
   // private int l;
    //Queue<Integer> queue=new LinkedList<Integer>();
    //int a,b,k,k1,i,h,l;

    int phil[]=new int[5];
    private Timer timer;
    private boolean chromeShown;
    private int x;
    private int m;
    private int n;
    private int flag[]=new int[5];
    public anewupdate() {
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(930, 693);
        JPanel panel = new JPanel();
      
       jLabel = new JLabel(new ImageIcon("right1.png"));
        //jLabel.setBounds(0, 0, 584, 561);
        chromeShown = true;
        x = 0;
        m = 0;
        panel.setLayout(null);
        panel.add(jLabel);
        

        this.getContentPane().add(panel);
        
        JLabel label_1 = new JLabel("");
        label_1.setIcon(new ImageIcon("phi2.png"));
        label_1.setBounds(345, 71, 119, 166);
        panel.add(label_1);
        
        JLabel label_2 = new JLabel("");
        label_2.setIcon(new ImageIcon("side1.png"));
        label_2.setBounds(154, 238, 119, 134);
        panel.add(label_2);
        
        JLabel label_3 = new JLabel("");
        label_3.setIcon(new ImageIcon("User.png"));
        label_3.setBounds(263, 426, 128, 117);
        panel.add(label_3);
        
        
        
        JLabel label_4 = new JLabel("");
        label_4.setIcon(new ImageIcon("right1.png"));
        label_4.setBounds(569, 238, 156, 128);
        panel.add(label_4);
        
        JLabel label_5 = new JLabel("");
        label_5.setIcon(new ImageIcon("right1.png"));
        label_5.setBounds(469, 406, 148, 166);
        panel.add(label_5);
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        lblNewLabel.setBounds(307, 201, 100, 90);
        panel.add(lblNewLabel);
        
        JLabel label_6 = new JLabel("");
        label_6.setIcon(new ImageIcon("whitespoon.png"));
        label_6.setBounds(270, 359, 119, 77);
        panel.add(label_6);
        
        JLabel label_7 = new JLabel("");
        label_7.setIcon(new ImageIcon("strspoon.png"));
        label_7.setBounds(401, 409, 46, 89);
        panel.add(label_7);
        
        JLabel label_8 = new JLabel("");
        label_8.setIcon(new ImageIcon(""));
        //whitespoon - Copy.png
        label_8.setBounds(494, 278, 148, 117);
        panel.add(label_8);
        
        JLabel label_9 = new JLabel("");
        label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        label_9.setBounds(457, 202, 119, 89);
        panel.add(label_9);
        
        JLabel label_15 = new JLabel("");
        label_15.setIcon(new ImageIcon(""));
        //whitespoon - Copy (2).png
        label_15.setBounds(277, 248, 69, 64);
        panel.add(label_15);
        
        JLabel label_16 = new JLabel("");
        label_16.setIcon(new ImageIcon(""));
        //whitespoon.png
        label_16.setBounds(266, 302, 89, 98);
        panel.add(label_16);
        
        JLabel label = new JLabel("");
        label.setIcon(new ImageIcon("food00.jpg"));
        label.setBounds(307, 290, 74, 58);
        panel.add(label);
        
        JLabel label_14 = new JLabel("");
        label_14.setIcon(new ImageIcon(""));
        //whitespoon.png
        label_14.setBounds(280, 384, 69, 86);
        panel.add(label_14);
        
        JLabel label_17 = new JLabel("");
        label_17.setIcon(new ImageIcon(""));
        //whitespoon - Copy.png
        label_17.setBounds(352, 406, 81, 77);
        panel.add(label_17);
        
        JLabel label_13 = new JLabel("");
        label_13.setIcon(new ImageIcon("food00.jpg"));
        label_13.setBounds(322, 375, 69, 61);
        panel.add(label_13);
        
        JLabel label_18 = new JLabel("");
        label_18.setIcon(new ImageIcon(""));
        //whitespoon.png
        label_18.setBounds(434, 394, 72, 89);
        panel.add(label_18);
        
        JLabel label_19 = new JLabel("");
        label_19.setIcon(new ImageIcon(""));
        //whitespoon - Copy.png
        
        label_19.setBounds(504, 384, 66, 90);
        panel.add(label_19);
        
        JLabel label_12 = new JLabel("");
        label_12.setIcon(new ImageIcon("food00.jpg"));
        label_12.setBounds(457, 379, 74, 71);
        panel.add(label_12);
        
        JLabel label_20 = new JLabel("");
        label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        
        label_20.setBounds(494, 277, 123, 193);
        panel.add(label_20);
        
        JLabel label_21 = new JLabel("");
        label_21.setIcon(new ImageIcon(""));
        //whitespoon - Copy (3).png
        label_21.setBounds(485, 197, 157, 151);
        panel.add(label_21);
        
        JLabel label_11 = new JLabel("");
        label_11.setIcon(new ImageIcon("food00.jpg"));
        label_11.setBounds(477, 277, 69, 64);
        panel.add(label_11);
        
        JLabel label_22 = new JLabel("");
        label_22.setIcon(new ImageIcon(""));
        label_22.setBounds(345, 176, 111, 89);
        //whitespoon - Copy (2).png
        panel.add(label_22);
        
        Label lbl = new Label("THINKING");
        lbl.setFont(new Font("Serif", Font.BOLD, 14));
        
        lbl.setAlignment(Label.CENTER);
        lbl.setBackground(new Color(0, 0, 255));
        lbl.setBounds(457, 91, 81, 22);
        panel.add(lbl);
        
        
        JLabel label_23 = new JLabel("");
        label_23.setIcon(new ImageIcon(""));
        //whitespoon - Copy (3).png
        label_23.setBounds(417, 176, 64, 75);
        panel.add(label_23);
        
        JLabel label_24 = new JLabel("");
        label_24.setIcon(new ImageIcon("food00.jpg"));
        label_24.setBounds(381, 220, 66, 58);
        panel.add(label_24);
        
        JLabel label_10 = new JLabel("");
        label_10.setIcon(new ImageIcon("table.png"));
        label_10.setBounds(290, 162, 382, 347);
        panel.add(label_10);
        
        JLabel lblDiningPhilosophers = new JLabel("DINING PHILOSOPHERS");
        lblDiningPhilosophers.setBackground(new Color(245, 222, 179));
        lblDiningPhilosophers.setFont(new Font("Poor Richard", Font.BOLD, 20));
        lblDiningPhilosophers.setForeground(new Color(72, 61, 139));
        lblDiningPhilosophers.setBounds(352, 11, 306, 24);
        panel.add(lblDiningPhilosophers);
        
        
        JLabel lblNewLabel_1 = new JLabel("PHILOSOPHER 1");
        lblNewLabel_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
        lblNewLabel_1.setForeground(new Color(139, 0, 139));
        lblNewLabel_1.setBounds(460, 71, 116, 14);
        panel.add(lblNewLabel_1);
        
        JLabel lblPhilosopher = new JLabel("PHILOSOPHER 2");
        lblPhilosopher.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
        lblPhilosopher.setForeground(new Color(139, 0, 139));
        lblPhilosopher.setBounds(108, 223, 111, 14);
        panel.add(lblPhilosopher);
        
        JLabel lblPhilosopher_1 = new JLabel("PHILOSOPHER 3");
        lblPhilosopher_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
        lblPhilosopher_1.setForeground(new Color(139, 0, 139));
        lblPhilosopher_1.setBounds(154, 447, 134, 14);
        panel.add(lblPhilosopher_1);
        
        JLabel lblPhilosopher_2 = new JLabel("PHILOSOPHER 5");
        lblPhilosopher_2.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
        lblPhilosopher_2.setForeground(new Color(139, 0, 139));
        lblPhilosopher_2.setBounds(682, 237, 136, 14);
        panel.add(lblPhilosopher_2);
        
        JLabel lblPhilosopher_3 = new JLabel("PHILOSOPHER 4");
        lblPhilosopher_3.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
        lblPhilosopher_3.setForeground(new Color(139, 0, 139));
        lblPhilosopher_3.setBounds(569, 426, 119, 14);
        panel.add(lblPhilosopher_3);
        
        JLabel lblNewLabel_3 = new JLabel("THINKING");
        lblNewLabel_3.setBackground(new Color(0, 0, 255));
        lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 14));
        lblNewLabel_3.setForeground(new Color(138, 43, 226));
        lblNewLabel_3.setBounds(108, 251, 79, 14);
        panel.add(lblNewLabel_3);
        

        JLabel lblThinking = new JLabel("THINKING");
        lblThinking.setFont(new Font("Serif", Font.BOLD, 14));;
        lblNewLabel_3.setForeground(new Color(138, 43, 226));
        lblThinking.setBounds(469, 96, 77, 14);
        panel.add(lblThinking);
        
        
        JLabel lblPhi = new JLabel("THINKING");
        lblPhi.setBackground(new Color(0, 0, 255));
        lblPhi.setFont(new Font("Serif", Font.BOLD, 14));;
        lblPhi.setForeground(new Color(138, 43, 226));
        lblPhi.setBounds(188, 472, 85, 14);
        panel.add(lblPhi);
        
        JLabel lblPhi_1 = new JLabel("THINKING");
        lblPhi_1.setFont(new Font("Serif", Font.BOLD, 14));;
        lblPhi_1.setForeground(new Color(138, 43, 226));
        lblPhi_1.setBounds(569, 447, 73, 14);
        panel.add(lblPhi_1);
        
        JLabel lblPhi_2 = new JLabel("THINKING");
        lblPhi_2.setBackground(new Color(0, 0, 255));
        lblPhi_2.setFont(new Font("Serif", Font.BOLD, 14));;
        lblPhi_2.setForeground(new Color(138, 43, 226));
        lblPhi_2.setBounds(692, 264, 81, 14);
        panel.add(lblPhi_2);
        
        JButton btnStop = new JButton("EXIT");
        btnStop.setBackground(new Color(0, 0, 0));
        btnStop.setForeground(new Color(102, 205, 170));
        btnStop.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {

				/*lblThinking.setText("THINKING");
				lblNewLabel_3.setText("THINKING");
				lblPhi.setText("THINKING");
				lblPhi_1.setText("THINKING");
				lblPhi_2.setText("THINKING");*/
        		
        	}
        });
        btnStop.setBounds(666, 554, 89, 23);
        panel.add(btnStop);
        this.setVisible(true);
      
 
        JButton btnStart = new JButton("START");
        btnStart.setBackground(new Color(0, 0, 0));
        btnStart.setForeground(new Color(64, 224, 208));
        btnStart.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		int interval = 5000; // repeating every 1000 ms
        		new Timer(interval, new ActionListener() {
        		    @Override
        		    public void actionPerformed(ActionEvent e) {
        		    	Queue<Integer> queue=new LinkedList<Integer>();
        				int a,b,k,k1,i,h;
        				int flag[]=new int[5];
        				int phil[]=new int[5];
        				
        					for(i=0;i<5;i++)
        					{
        					flag[i]=0;
        					}
        					for(i=0;i<5;i++)
        					{
        						Random rand= new Random();
        						 k=rand.nextInt(5);
        						while(true)
        						{
        						 k1=rand.nextInt(5);
        						if(k1!=k)
        							break;
        						}
        						queue.add(k);
        						queue.add(k1);
        						a=queue.remove();
        						b=queue.remove();
        						flag[a]=1;
        						flag[b]=1;
        						//System.out.println(a+"###"+b);
        						
        						if(flag[(a+1)%5]!=2&&flag[(a+5)%5]!=2)
        						{
        							flag[a]=2;
        						}
        						else 
        						{
        							//flag[a]=3;
        							queue.add(a);
        						}
        						if(flag[(b+1)%5]!=2&&flag[(b+4)%5]!=2)
        						{
        							flag[b]=2;
        						}
        						else
        						{
        							//flag[b]=3;
        							queue.add(b);
        						}
        						for(h=0;h<5;h++)
        						{
        							if(flag[h]==0)
        							{
        								System.out.print("THINKING"+' ');
        								
        								
        								
        							}
        							if(flag[h]==1)
        							{
        								System.out.print("HUNGRY"+' ');
        								
        							}
        							if(flag[h]==2)
        							{
        								System.out.print( "EATING"+' ');
        							}
        						}
        						System.out.println("\n");
        						/*try
        						{
        							TimeUnit.SECONDS.sleep(5);
        							
        						}
        						catch(Exception e)
        						{
        							System.out.println(e);
        						}*/
        						if(flag[a]==2)
        						{
        							flag[a]=0;
        						}
        						if(flag[b]==2)
        						{
        							flag[b]=0;		
        						}
        					
        						if(flag[0]==0)
        						{
        							lblThinking.setText("THINKING");
        						}
        						if(flag[0]==1)
        						{
        							lblThinking.setText("HUNGRY");
        						}
        						if(flag[0]==2)
        						{
        							lblThinking.setText("EATING");
        						}
        						if(flag[1]==0)
        						{
        							
                					lblNewLabel_3.setText("THINKING");
        						}
        						if(flag[1]==1)
        						{
        							
                					lblNewLabel_3.setText("HUNGRY");
        						}
        						if(flag[1]==2)
        						{	
                					lblNewLabel_3.setText("EATING");
        						}
        						if(flag[2]==0)
        						{
        							lblPhi.setText("THINKING");
        						}
        						if(flag[2]==1)
        						{
        							lblPhi.setText("HUNGRY");
        						}
        						if(flag[2]==2)
        						{
        							lblPhi.setText("EATING");
        						}
        						if(flag[3]==0)
        						{
        							lblPhi_1.setText("THINKING");
        						}
        						if(flag[3]==1)
        						{
        							lblPhi_1.setText("HUNGRY");
        						}
        						if(flag[3]==2)
        						{
        							lblPhi_1.setText("EATING");
        						}
        						if(flag[4]==0)
        						{
        							lblPhi_2.setText("THINKING");
        						}
        						if(flag[4]==1)
        						{
        							lblPhi_2.setText("HUNGRY");
        						}
        						if(flag[4]==2)
        						{
        							lblPhi_2.setText("EATING");
        						}
        				
        					int l;
        					for(l=0;l<=4;l++)
        					{
        						if(flag[l]==2)
        						{
        							if(l==0)
        							{
        								
        								lblNewLabel.setIcon(new ImageIcon(""));
        								lbl.setBackground(new Color(0, 255 , 0));
        								label_22.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        			                	label_9.setIcon(new ImageIcon(""));
        			                	label_23.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        			                	
        			                        	
        			                	 //label_24.setIcon(new ImageIcon("food2.jpg"));
        			                	 
        			                	
        			                	 label_24.setIcon(new ImageIcon("food6.jpg"));
        			                	
        			                	
        			                	
        							}
        							if(l==1)
        							{
        								lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        								lblNewLabel.setIcon(new ImageIcon(""));
        								label_15.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        								label_6.setIcon(new ImageIcon(""));
        			                	label_16.setIcon(new ImageIcon("whitespoon.png"));
        			                	label.setIcon(new ImageIcon("food6.jpg"));
        								
        							}
        							if(l==2)
        							{
        								 label_13.setIcon(new ImageIcon("food6.jpg"));
        								 lblPhi.setBackground(new Color(0,  255,0));
        								label_6.setIcon(new ImageIcon(""));
        		                    	label_14.setIcon(new ImageIcon("whitespoon.png"));
        		                    	label_7.setIcon(new ImageIcon(""));
        		                    	label_17.setIcon(new ImageIcon("whitespoon - Copy.png"));
        							}
        							if(l==3)
        							{
        								label_12.setIcon(new ImageIcon("food6.jpg"));
        								lblPhi_1.setBackground(new Color(0,  255,0));
        								label_7.setIcon(new ImageIcon(""));
        			                	label_18.setIcon(new ImageIcon("whitespoon.png"));
        			                	label_20.setIcon(new ImageIcon(""));
        			                	label_19.setIcon(new ImageIcon("whitespoon - Copy.png"));
        							}
        							if(l==4)
        							{
        								label_11.setIcon(new ImageIcon("food6.jpg"));
       								 lblPhi_2.setBackground(new Color(0,  255 ,0));
       								label_20.setIcon(new ImageIcon(""));
       			                	label_8.setIcon(new ImageIcon("whitespoon - Copy.png"));
       			                	label_9.setIcon(new ImageIcon(""));
       			                	label_21.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        							}
        						}
        						if( flag[l]==0)
        						{
        							if(l==0)
        							{
        								lbl.setBackground(new Color( 0,0,255 ));
        								if(flag[1]==2 && flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
         									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
         									label_24.setIcon(new ImageIcon("food00.jpg"));
         									label.setIcon(new ImageIcon("food6.jpg"));
         									label_11.setIcon(new ImageIcon("food6.jpg"));
         									lblNewLabel.setIcon(new ImageIcon(""));
             								label_22.setIcon(new ImageIcon(""));
             			                	label_9.setIcon(new ImageIcon(""));
             			                	label_23.setIcon(new ImageIcon(""));
            			                	
        								}
        								else if(flag[1]==2)
        								{
        									label_24.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_22.setIcon(new ImageIcon(""));
            								label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
            								label_23.setIcon(new ImageIcon(""));
        								}
        								else if(flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
         									label_11.setIcon(new ImageIcon("food6.jpg"));
         									label_24.setIcon(new ImageIcon("food00.jpg"));
         									//label.setIcon(new ImageIcon("food00.jpg"));
         									 lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
         									label_22.setIcon(new ImageIcon(""));
             								label_9.setIcon(new ImageIcon(""));
             								label_23.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_24.setIcon(new ImageIcon("food00.jpg"));
        									//label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        									label_22.setIcon(new ImageIcon(""));
        									label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        									label_23.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==1)
        							{
        								lblNewLabel_3.setBackground(new Color(0,  0,255 ));
        								if(flag[0]==2&& flag[2]==2)
        								{
        									lblPhi.setBackground(new Color(0,  255,0));
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label.setIcon(new ImageIcon("food00.jpg"));
        									 label_13.setIcon(new ImageIcon("food6.jpg"));


        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon(""));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else if(flag[0]==2)
        								{
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label.setIcon(new ImageIcon("food00.jpg"));

        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon("whitespoon.png"));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else if(flag[2]==2)
        								{
        									lblPhi.setBackground(new Color(0,  255,0));
        									//))label_24.setIcon(new ImageIcon("food00.jpg"));
        									 label_13.setIcon(new ImageIcon("food6.jpg"));

        									label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon(""));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        									label_15.setIcon(new ImageIcon(""));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_16.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==2)
        							{
        								lblPhi.setBackground(new Color(0,  0,255));
        								if(flag[1]==2 && flag[3]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
        									label_6.setIcon(new ImageIcon(""));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon(""));
            		                    	label_17.setIcon(new ImageIcon(""));
            							
        								}
        								else if(flag[1]==2)
        								{

        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									label_6.setIcon(new ImageIcon(""));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon("strspoon.png"));
            		                    	label_17.setIcon(new ImageIcon(""));

        								}
        								else if(flag[3]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									//))label.setIcon(new ImageIcon("food00.jpg"));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon(""));
            		                    	label_17.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									//))label.setIcon(new ImageIcon("food00.jpg"));
        									label_7.setIcon(new ImageIcon("strspoon.png"));
        									label_17.setIcon(new ImageIcon(""));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_14.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==3)
        							{
        								lblPhi_1.setBackground(new Color(0,  0,255));
        								if(flag[2]==2 && flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
         									lblPhi.setBackground(new Color(0,  255,0));
         									label_12.setIcon(new ImageIcon("food00.jpg"));
         									//label_24.setIcon(new ImageIcon("food00.jpg"));
         									 label_13.setIcon(new ImageIcon("food6.jpg"));
         									 label_11.setIcon(new ImageIcon("food6.jpg"));
         									label_7.setIcon(new ImageIcon(""));
             			                	label_18.setIcon(new ImageIcon(""));
             			                	label_20.setIcon(new ImageIcon(""));
             			                	label_19.setIcon(new ImageIcon(""));
            							
        								}
        								else if(flag[2]==2)
        								{

        									label_13.setIcon(new ImageIcon("food6.jpg"));
       									 label_12.setIcon(new ImageIcon("food00.jpg"));
       									 lblPhi.setBackground(new Color(0,  255,0));
       									label_7.setIcon(new ImageIcon(""));
           			                	label_18.setIcon(new ImageIcon(""));
           			                	label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
           			                	label_19.setIcon(new ImageIcon(""));

        								}
        								else if(flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
         									label_12.setIcon(new ImageIcon("food00.jpg"));
         									label_7.setIcon(new ImageIcon("strspoon.png"));
         									label_11.setIcon(new ImageIcon("food6.jpg"));
             			                	label_18.setIcon(new ImageIcon(""));
             			                	label_20.setIcon(new ImageIcon(""));
             			                	label_19.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_12.setIcon(new ImageIcon("food00.jpg"));
        									label_7.setIcon(new ImageIcon("strspoon.png"));
        									label_18.setIcon(new ImageIcon(""));
        									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        									label_19.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==4)
        							{
        								 lblPhi_2.setBackground(new Color(0, 0, 255 ));
         								//))label.setIcon(new ImageIcon("food00.jpg"));
         								label_11.setIcon(new ImageIcon("food00.jpg"));
        								if(flag[3]==2 && flag[0]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
        									label_20.setIcon(new ImageIcon(""));
            			                	label_8.setIcon(new ImageIcon(""));
            			                	label_9.setIcon(new ImageIcon(""));
            			                	label_21.setIcon(new ImageIcon(""));            							
        								}
        								else if(flag[3]==2)
        								{

        									lblPhi_1.setBackground(new Color(0,  255,0));

        									label_20.setIcon(new ImageIcon(""));
            			                	label_8.setIcon(new ImageIcon(""));
            			                	label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
            			                	label_21.setIcon(new ImageIcon(""));
            			                	label_12.setIcon(new ImageIcon("food6.jpg"));
        								}
        								else if(flag[0]==2)
        								{		lbl.setBackground(new Color(0, 255 , 0));
    									label_24.setIcon(new ImageIcon("food6.jpg"));
    									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
    			                	label_8.setIcon(new ImageIcon(""));
    			                	label_9.setIcon(new ImageIcon(""));
    			                	label_21.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        									label_21.setIcon(new ImageIcon(""));
        									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        									label_8.setIcon(new ImageIcon(""));
        								}
        							}
        						}
        						if( flag[l]==1)
        						{
        							if(l==0)
        							{lbl.setBackground(new Color( 255,0,0 ));
        								if(flag[1]==2 && flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
         									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
         									label_24.setIcon(new ImageIcon("food00.jpg"));
         									label.setIcon(new ImageIcon("food6.jpg"));
         									label_11.setIcon(new ImageIcon("food6.jpg"));
         									lblNewLabel.setIcon(new ImageIcon(""));
             								label_22.setIcon(new ImageIcon(""));
             			                	label_9.setIcon(new ImageIcon(""));
             			                	label_23.setIcon(new ImageIcon(""));
            			                	
        								}
        								else if(flag[1]==2)
        								{
        									label_24.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_22.setIcon(new ImageIcon(""));
            								label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
            								label_23.setIcon(new ImageIcon(""));
        								}
        								else if(flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
        									label_11.setIcon(new ImageIcon("food6.jpg"));
        									label_24.setIcon(new ImageIcon("food00.jpg"));
        									//label.setIcon(new ImageIcon("food00.jpg"));
        									 lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        									label_22.setIcon(new ImageIcon(""));
            								label_9.setIcon(new ImageIcon(""));
            								label_23.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_24.setIcon(new ImageIcon("food00.jpg"));
        									//label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        									label_22.setIcon(new ImageIcon(""));
        									label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        									label_23.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==1)
        							{
        								lblNewLabel_3.setBackground(new Color(  255 ,0,0));
        								if(flag[0]==2 && flag[2]==2)
        								{
        									lblPhi.setBackground(new Color(0,  255,0));
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label.setIcon(new ImageIcon("food00.jpg"));
        									 label_13.setIcon(new ImageIcon("food6.jpg"));


        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon(""));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else if(flag[0]==2)
        								{
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label.setIcon(new ImageIcon("food00.jpg"));

        									lblNewLabel.setIcon(new ImageIcon(""));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon("whitespoon.png"));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else if(flag[2]==2)
        								{
        									lblPhi.setBackground(new Color(0,  255,0));
        									//))label_24.setIcon(new ImageIcon("food00.jpg"));
        									 label_13.setIcon(new ImageIcon("food6.jpg"));

        									label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
            								label_15.setIcon(new ImageIcon(""));
            								label_6.setIcon(new ImageIcon(""));
            			                	label_16.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									
        									//))label_24.setIcon(new ImageIcon("food00.jpg"));
        									label.setIcon(new ImageIcon("food00.jpg"));
        									lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
        									label_15.setIcon(new ImageIcon(""));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_16.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==2)
        							{
        								lblPhi.setBackground(new Color(255,0,0));
        								if(flag[3]==2 && flag[1]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
        									label_6.setIcon(new ImageIcon(""));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon(""));
            		                    	label_17.setIcon(new ImageIcon(""));
            							
        								}
        								else if(flag[1]==2)
        								{
        									lblNewLabel_3.setBackground(new Color(0,  255 , 0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									label.setIcon(new ImageIcon("food6.jpg"));
        									label_6.setIcon(new ImageIcon(""));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon("strspoon.png"));
            		                    	label_17.setIcon(new ImageIcon(""));

        								}
        								else if(flag[3]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									//))label.setIcon(new ImageIcon("food00.jpg"));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
            		                    	label_14.setIcon(new ImageIcon(""));
            		                    	label_7.setIcon(new ImageIcon(""));
            		                    	label_17.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_13.setIcon(new ImageIcon("food00.jpg"));
        									//))label.setIcon(new ImageIcon("food00.jpg"));
        									label_7.setIcon(new ImageIcon("strspoon.png"));
        									label_17.setIcon(new ImageIcon(""));
        									label_6.setIcon(new ImageIcon("whitespoon.png"));
        									label_14.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==3)
        							{
        								lblPhi_1.setBackground(new Color(  255,0,0));
        								if(flag[2]==2 && flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
        									lblPhi.setBackground(new Color(0,  255,0));
        									label_12.setIcon(new ImageIcon("food00.jpg"));
        									//label_24.setIcon(new ImageIcon("food00.jpg"));
        									 label_13.setIcon(new ImageIcon("food6.jpg"));
        									 label_11.setIcon(new ImageIcon("food6.jpg"));
        									label_7.setIcon(new ImageIcon(""));
            			                	label_18.setIcon(new ImageIcon(""));
            			                	label_20.setIcon(new ImageIcon(""));
            			                	label_19.setIcon(new ImageIcon(""));
            							
        								}
        								
        								else if(flag[2]==2)
        								{
        									 label_13.setIcon(new ImageIcon("food6.jpg"));
        									 label_12.setIcon(new ImageIcon("food00.jpg"));
        									 lblPhi.setBackground(new Color(0,  255,0));
        									label_7.setIcon(new ImageIcon(""));
            			                	label_18.setIcon(new ImageIcon(""));
            			                	label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
            			                	label_19.setIcon(new ImageIcon(""));

        								}
        								else if(flag[4]==2)
        								{
        									 lblPhi_2.setBackground(new Color(0,  255 ,0));
        									label_12.setIcon(new ImageIcon("food00.jpg"));
        									label_7.setIcon(new ImageIcon("strspoon.png"));
        									label_11.setIcon(new ImageIcon("food6.jpg"));
            			                	label_18.setIcon(new ImageIcon(""));
            			                	label_20.setIcon(new ImageIcon(""));
            			                	label_19.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_12.setIcon(new ImageIcon("food00.jpg"));
        									label_7.setIcon(new ImageIcon("strspoon.png"));
        									label_18.setIcon(new ImageIcon(""));
        									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        									label_19.setIcon(new ImageIcon(""));
        								}
        							}
        							if(l==4)
        							{
        								lblPhi_2.setBackground(new Color(255 ,0,0));
        								//))label.setIcon(new ImageIcon("food00.jpg"));
        								label_11.setIcon(new ImageIcon("food00.jpg"));
        								if(flag[3]==2 && flag[0]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label_12.setIcon(new ImageIcon("food6.jpg"));
        									label_20.setIcon(new ImageIcon(""));
            			                	label_8.setIcon(new ImageIcon(""));
            			                	label_9.setIcon(new ImageIcon(""));
            			                	label_21.setIcon(new ImageIcon(""));
            							
        								}
        								else if(flag[3]==2)
        								{
        									lblPhi_1.setBackground(new Color(0,  255,0));
        									label_20.setIcon(new ImageIcon(""));
            			                	label_8.setIcon(new ImageIcon(""));
            			                	label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
            			                	label_21.setIcon(new ImageIcon(""));
            			                	label_12.setIcon(new ImageIcon("food6.jpg"));
        								}
        								else if(flag[0]==2)
        								{	
        									lbl.setBackground(new Color(0, 255 , 0));
        									label_24.setIcon(new ImageIcon("food6.jpg"));
        									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        			                	label_8.setIcon(new ImageIcon(""));
        			                	label_9.setIcon(new ImageIcon(""));
        			                	label_21.setIcon(new ImageIcon(""));
        								}
        								else
        								{
        									label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
        									label_21.setIcon(new ImageIcon(""));
        									label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));
        									label_8.setIcon(new ImageIcon(""));
        								}
        							}
        						}
        					}
        				}
        		    
        		    		
        		        // do whatever painting that you want
        		    }
        		}).start();
        		
        		
        		
        	}
        	 
            	 
            	 
             
        
        
        
        });
        btnStart.setBounds(118, 26, 89, 23);
        panel.add(btnStart);
      
        
        
        	
        
             
		
    }
    public  void req() {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                new edited();
            }
        });

    }
}