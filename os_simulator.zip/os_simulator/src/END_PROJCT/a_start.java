package END_PROJCT;

import java.awt.EventQueue;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JFrame;
import javax.swing.JList;
import java.awt.Color;
import javax.swing.border.BevelBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.JTextArea;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.util.Random;

import javax.swing.ImageIcon;
import java.awt.ScrollPane;
import java.awt.Label;
import java.awt.Font;
import java.awt.Button;
import java.awt.SystemColor;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeEvent;

public class a_start {

	
	private final Action action = new SwingAction();
	private final Action action_1 = new SwingAction_1();
	
	private JFrame frame;
	private JTextField rr_result;
	private JButton fcfs;
	private JTextField fcfs_result;
	private JButton btnNewButton;
	private JTextField sjf_result;
	private JButton btnGenerateInput;
	float values[]=new float[5];
	private JTextField prior;
	private JButton btnPriority;
	private JTextField prior_res;
	private JScrollPane scrollPane1;
	private JTable table_1;
	private JTable tb;
	private int n,n1,k;
	public int at2[];
	public int at[];
	public int bt[];
	public int at5[];
	public int bt5[];
	public int at1[];
	public int bt2[];
	public int bt1[];
	public int at4[];
	public int bt4[];
	public int at3[];
	public int bt3[];
	public String inp_table[][];
	/**
	 * Launch the application.
	 */
	public void req() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					a_start window = new a_start();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public a_start() {
		initialize();
	}

	 void quit(JFrame x) {
		    if (JOptionPane.showConfirmDialog(
		      frame,
		      "Are you sure you want to exit?",
		      "Please confirm",
		      JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION
		    ) {
		    	
		    	x.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		      
		    }
		  }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.controlHighlight);
		frame.setBounds(100, 100, 1244, 557);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.addWindowListener(new WindowAdapter() {
		      @Override
		      public void windowClosing(WindowEvent event) {
		        quit(frame);
		      }
		    });
		
		
		
		JMenuBar bar=new JMenuBar();
		JMenu file,process,dinning,page,disk,help;
		JMenuItem exiti,homei,processi,dinningi,pagei,diski,helpi;
		
		file=new JMenu("File");
		process=new JMenu("Process");
		dinning=new JMenu("Dinning");
		page=new JMenu("Page");
		disk=new JMenu("Disk");
		help=new JMenu("Help");
		bar.add(file);
		bar.add(process);
		bar.add(dinning);
		bar.add(page);
		bar.add(disk);
		bar.add(help);
		ImageIcon si11=new ImageIcon("/home/indian/Documents/exit.png");
		ImageIcon si12=new ImageIcon("/home/indian/Documents/blue-home-icon.png");
		ImageIcon si4=new ImageIcon("/home/indian/Documents/disk1.png");
		exiti=new JMenuItem("Exit",si11);
		
		homei=new JMenuItem("Home",si12);
		homei.setMnemonic(KeyEvent.VK_H);
		processi=new JMenuItem("CPU Scheduling");
		dinningi=new JMenuItem("Dinning Philosophers");
		pagei=new JMenuItem("Page Replacement");
		diski=new JMenuItem("Disk Management",si4);
		helpi=new JMenuItem("Help");
		file.add(exiti);
		file.add(homei);
		process.add(processi);
		dinning.add(dinningi);
		page.add(pagei);
		disk.add(diski);
		diski.setMnemonic(KeyEvent.VK_D);
		help.add(helpi);
		frame.setJMenuBar(bar);
		
		
		exiti.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				quit(frame);
			}
		});

diski.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				disk_first ds1=new disk_first();
				ds1.req();
			}
		});
processi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		a_start a1=new a_start();
		a1.req();
	}
});
dinningi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		edited z=new edited();
		z.req();
	}
});
pagei.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		page_first pf=new page_first();
		pf.req();
	}
});
		
		
		
		/*JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1297, 21);
		frame.getContentPane().add(menuBar);
		
		JMenu mnFile = new JMenu("FILE");
		menuBar.add(mnFile);
		
		JMenu mnNewProject = new JMenu("New Project");
		mnFile.add(mnNewProject);
		
		JMenuItem mntmProjects = new JMenuItem("Projects");
		mnNewProject.add(mntmProjects);
		
		JMenu mnSource = new JMenu("Source");
		mnFile.add(mnSource);
		
		JSeparator separator = new JSeparator();
		mnFile.add(separator);
		JMenu mnDesign = new JMenu("design");
		mnFile.add(mnDesign);
		JMenuItem mntmClose = new JMenuItem("CLOSE");
		mntmClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				newfran second = new newfran();
				second.setVisible(true);
				frame.dispose();
			
			}
		});
		
		mnFile.add(mntmClose);
		
		JSeparator separator_1 = new JSeparator();
		mnFile.add(separator_1);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(frame, "Are you sure");
				System.exit(JFrame.EXIT_ON_CLOSE);
				
			
			}
			
		});
		mnFile.add(mntmExit);*/
		
		
		JLabel lbl_1 = new JLabel("");
		lbl_1.setIcon(new ImageIcon(" "));
		lbl_1.setBounds(214, 94, 38, 39);
		frame.getContentPane().add(lbl_1);
		
		JLabel lbl_2 = new JLabel("");
		lbl_2.setIcon(new ImageIcon(" "));
		lbl_2.setBounds(374, 89, 31, 44);
		frame.getContentPane().add(lbl_2);
		
		JLabel lbl_3 = new JLabel("");
		lbl_3.setIcon(new ImageIcon(" "));
		lbl_3.setBounds(523, 89, 28, 39);
		frame.getContentPane().add(lbl_3);
		
		JLabel lbl_4 = new JLabel("");
		lbl_4.setIcon(new ImageIcon(" "));
		lbl_4.setBounds(663, 93, 28, 40);
		frame.getContentPane().add(lbl_4);
		
		JLabel lbl_5 = new JLabel("");
		lbl_5.setIcon(new ImageIcon(" "));
		lbl_5.setBounds(813, 89, 32, 45);
		frame.getContentPane().add(lbl_5);
		
		JLabel lbl_6 = new JLabel("");
		lbl_6.setIcon(new ImageIcon(" "));
		lbl_6.setBounds(961, 89, 28, 40);
		frame.getContentPane().add(lbl_6);
		
		JLabel lbl_8 = new JLabel("");
		lbl_8.setIcon(new ImageIcon(" "));
		lbl_8.setBounds(523, 194, 25, 40);
		frame.getContentPane().add(lbl_8);
		
		JLabel lbl_9 = new JLabel("");
		lbl_9.setIcon(new ImageIcon(" "));
		lbl_9.setBounds(663, 194, 28, 40);
		frame.getContentPane().add(lbl_9);
		
		JLabel lbl_7 = new JLabel("");
		lbl_7.setIcon(new ImageIcon(" "));
		lbl_7.setBounds(1111, 84, 38, 49);
		frame.getContentPane().add(lbl_7);
		
		
		Label label = new Label(" ");
		label.setFont(new Font("Dialog", Font.BOLD, 13));
		label.setBackground(SystemColor.controlHighlight);
		label.setBounds(113, 89, 52, 22);
		frame.getContentPane().add(label);
		
		Label label_1 = new Label(" ");
		label_1.setFont(new Font("Dialog", Font.BOLD, 13));
		label_1.setBackground(SystemColor.controlHighlight);
		label_1.setBounds(171, 89, 18, 22);
		frame.getContentPane().add(label_1);
		
		Label label_2 = new Label(" ");
		label_2.setFont(new Font("Dialog", Font.BOLD, 10));
		label_2.setBackground(SystemColor.controlHighlight);
		label_2.setBounds(103, 112, 70, 21);
		frame.getContentPane().add(label_2);
		
		Label label_3 = new Label(" ");
		label_3.setFont(new Font("Dialog", Font.BOLD, 11));
		label_3.setBackground(SystemColor.controlHighlight);
		label_3.setBounds(171, 112, 31, 21);
		frame.getContentPane().add(label_3);
		
		Label label_4 = new Label(" ");
		label_4.setFont(new Font("Dialog", Font.BOLD, 10));
		label_4.setBackground(SystemColor.controlHighlight);
		label_4.setBounds(87, 128, 86, 22);
		frame.getContentPane().add(label_4);
		
		Label label_5 = new Label(" ");
		label_5.setFont(new Font("Dialog", Font.BOLD, 11));
		label_5.setBackground( SystemColor.controlHighlight);
		label_5.setBounds(171, 128, 29, 22);
		frame.getContentPane().add(label_5);
		
		Label label_6 = new Label("");
		label_6.setBackground(SystemColor.controlHighlight);
		label_6.setBounds(87, 78, 115, 72);
		frame.getContentPane().add(label_6);
		
		Label label_7 = new Label(" ");
		label_7.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 13));
		label_7.setBackground(SystemColor.controlHighlight);
		label_7.setBounds(267, 89, 52, 22);
		frame.getContentPane().add(label_7);
		
		Label label_8 = new Label(" ");
		label_8.setFont(new Font("Dialog", Font.BOLD, 13));
		label_8.setBackground(SystemColor.controlHighlight);
		label_8.setBounds(325, 89, 37, 22);
		frame.getContentPane().add(label_8);
		
		Label label_9 = new Label("  ");
		label_9.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_9.setBackground(SystemColor.controlHighlight);
		label_9.setBounds(258, 112, 70, 21);
		frame.getContentPane().add(label_9);
		
		Label label_10 = new Label(" ");
		label_10.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 11));
		label_10.setBackground(SystemColor.controlHighlight);
		label_10.setBounds(334, 112, 29, 21);
		frame.getContentPane().add(label_10);
		
		Label label_11 = new Label(" ");
		label_11.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_11.setBackground(SystemColor.controlHighlight);
		label_11.setBounds(252, 128, 92, 22);
		frame.getContentPane().add(label_11);
		
		Label label_12 = new Label(" ");
		label_12.setFont(new Font("Dialog", Font.BOLD, 11));
		label_12.setBackground(SystemColor.controlHighlight);
		label_12.setBounds(344, 128, 29, 22);
		frame.getContentPane().add(label_12);
		
		Label label_13 = new Label("");
		label_13.setBackground(SystemColor.controlHighlight);
		label_13.setBounds(252, 78, 122, 72);
		frame.getContentPane().add(label_13);
		
		Label label_14 = new Label(" ");
		label_14.setFont(new Font("Dialog", Font.BOLD, 13));
		label_14.setBackground(SystemColor.controlHighlight);
		label_14.setBounds(419, 89, 52, 22);
		frame.getContentPane().add(label_14);
		
		Label label_15 = new Label(" ");
		label_15.setFont(new Font("Dialog", Font.BOLD, 13));
		label_15.setBackground(SystemColor.controlHighlight);
		label_15.setBounds(477, 89, 37, 22);
		frame.getContentPane().add(label_15);
		
		Label label_16 = new Label(" ");
		label_16.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_16.setBackground(SystemColor.controlHighlight);
		label_16.setBounds(407, 112, 64, 21);
		frame.getContentPane().add(label_16);
		
		Label label_17 = new Label(" ");
		label_17.setFont(new Font("Dialog", Font.BOLD, 11));
		label_17.setBackground(SystemColor.controlHighlight);
		label_17.setBounds(473, 112, 29, 21);
		frame.getContentPane().add(label_17);
		
		Label label_18 = new Label(" ");
		label_18.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 9));
		label_18.setBackground(SystemColor.controlHighlight);
		label_18.setBounds(407, 128, 86, 22);
		frame.getContentPane().add(label_18);
		
		Label label_19 = new Label(" ");
		label_19.setFont(new Font("Dialog", Font.BOLD, 9));
		label_19.setBackground(SystemColor.controlHighlight);
		label_19.setBounds(495, 128, 27, 22);
		frame.getContentPane().add(label_19);
		
		Label label_20 = new Label("");
		label_20.setBackground(SystemColor.controlHighlight);
		label_20.setBounds(407, 78, 115, 72);
		frame.getContentPane().add(label_20);
		
		Label label_21 = new Label(" ");
		label_21.setFont(new Font("Dialog", Font.BOLD, 13));
		label_21.setBackground(SystemColor.controlHighlight);
		label_21.setBounds(557, 89, 52, 22);
		frame.getContentPane().add(label_21);
		
		Label label_22 = new Label(" ");
		label_22.setFont(new Font("Dialog", Font.BOLD, 10));
		label_22.setBackground(SystemColor.controlHighlight);
		label_22.setBounds(557, 112, 64, 21);
		frame.getContentPane().add(label_22);
		
		Label label_23 = new Label(" ");
		label_23.setFont(new Font("Dialog", Font.BOLD, 11));
		label_23.setBackground(SystemColor.controlHighlight);
		label_23.setBounds(625, 112, 29, 21);
		frame.getContentPane().add(label_23);
		
		Label label_24 = new Label(" ");
		label_24.setFont(new Font("Dialog", Font.BOLD, 10));
		label_24.setBackground(SystemColor.controlHighlight);
		label_24.setBounds(552, 128, 85, 22);
		frame.getContentPane().add(label_24);
		
		Label label_25 = new Label(" ");
		label_25.setFont(new Font("Dialog", Font.BOLD, 11));
		label_25.setBackground(SystemColor.controlHighlight);
		label_25.setBounds(635, 128, 29, 22);
		frame.getContentPane().add(label_25);
		
		Label label_27 = new Label(" ");
		label_27.setFont(new Font("Dialog", Font.BOLD, 13));
		label_27.setBackground(SystemColor.controlHighlight);
		label_27.setBounds(615, 89, 37, 22);
		frame.getContentPane().add(label_27);
		
		Label label_26 = new Label("");
		label_26.setBackground(SystemColor.controlHighlight);
		label_26.setBounds(552, 78, 112, 72);
		frame.getContentPane().add(label_26);
		
		Label label_29 = new Label(" ");
		label_29.setFont(new Font("Dialog", Font.BOLD, 13));
		label_29.setBackground(SystemColor.controlHighlight);
		label_29.setBounds(705, 89, 52, 22);
		frame.getContentPane().add(label_29);
		
		Label label_30 = new Label(" ");
		label_30.setFont(new Font("Dialog", Font.BOLD, 13));
		label_30.setBackground(SystemColor.controlHighlight);
		label_30.setBounds(758, 89, 37, 22);
		frame.getContentPane().add(label_30);
		
		Label label_31 = new Label(" ");
		label_31.setFont(new Font("Dialog", Font.BOLD, 10));
		label_31.setBackground(SystemColor.controlHighlight);
		label_31.setBounds(705, 112, 64, 21);
		frame.getContentPane().add(label_31);
		
		Label label_32 = new Label(" ");
		label_32.setFont(new Font("Dialog", Font.BOLD, 11));
		label_32.setBackground(SystemColor.controlHighlight);
		label_32.setBounds(779, 112, 18, 21);
		frame.getContentPane().add(label_32);
		
		Label label_33 = new Label(" ");
		label_33.setFont(new Font("Dialog", Font.BOLD, 10));
		label_33.setBackground(SystemColor.controlHighlight);
		label_33.setBounds(692, 128, 85, 22);
		frame.getContentPane().add(label_33);
		
		Label label_34 = new Label(" ");
		label_34.setFont(new Font("Dialog", Font.BOLD, 11));
		label_34.setBackground(SystemColor.controlHighlight);
		label_34.setBounds(775, 128, 32, 22);
		frame.getContentPane().add(label_34);
		
		Label label_35 = new Label(" ");
		label_35.setBackground(SystemColor.controlHighlight);
		label_35.setForeground(SystemColor.controlHighlight);
		label_35.setBounds(692, 78, 122, 72);
		frame.getContentPane().add(label_35);
		
		Label label_36 = new Label(" ");
		label_36.setFont(new Font("Dialog", Font.BOLD, 13));
		label_36.setBackground(SystemColor.controlHighlight);
		label_36.setBounds(857, 89, 52, 22);
		frame.getContentPane().add(label_36);
		
		Label label_37 = new Label(" ");
		label_37.setFont(new Font("Dialog", Font.BOLD, 13));
		label_37.setBackground(SystemColor.controlHighlight);
		label_37.setBounds(915, 89, 37, 22);
		frame.getContentPane().add(label_37);
		
		Label label_38 = new Label(" ");
		label_38.setFont(new Font("Dialog", Font.BOLD, 10));
		label_38.setBackground(SystemColor.controlHighlight);
		label_38.setBounds(845, 112, 64, 21);
		frame.getContentPane().add(label_38);
		
		Label label_39 = new Label(" ");
		label_39.setFont(new Font("Dialog", Font.BOLD, 11));
		label_39.setBackground(SystemColor.controlHighlight);
		label_39.setBounds(915, 112, 18, 21);
		frame.getContentPane().add(label_39);
		
		Label label_40 = new Label(" ");
		label_40.setFont(new Font("Dialog", Font.BOLD, 10));
		label_40.setBackground(SystemColor.controlHighlight);
		label_40.setBounds(845, 128, 85, 22);
		frame.getContentPane().add(label_40);
		
		Label label_41 = new Label(" ");
		label_41.setFont(new Font("Dialog", Font.BOLD, 11));
		label_41.setBackground(SystemColor.controlHighlight);
		label_41.setBounds(934, 128, 28, 22);
		frame.getContentPane().add(label_41);
		
		Label label_42 = new Label("");
		label_42.setBackground(SystemColor.controlHighlight);
		label_42.setBounds(845, 78, 117, 72);
		frame.getContentPane().add(label_42);
		
		Label label_43 = new Label(" ");
		label_43.setFont(new Font("Dialog", Font.BOLD, 13));
		label_43.setBackground(SystemColor.controlHighlight);
		label_43.setBounds(1004, 89, 52, 22);
		frame.getContentPane().add(label_43);
		
		Label label_44 = new Label(" ");
		label_44.setFont(new Font("Dialog", Font.BOLD, 13));
		label_44.setBackground(SystemColor.controlHighlight);
		label_44.setBounds(1062, 89, 37, 22);
		frame.getContentPane().add(label_44);
		
		Label label_45 = new Label(" ");
		label_45.setFont(new Font("Dialog", Font.BOLD, 10));
		label_45.setBackground(SystemColor.controlHighlight);
		label_45.setBounds(1002, 112, 64, 21);
		frame.getContentPane().add(label_45);
		
		Label label_46 = new Label(" ");
		label_46.setFont(new Font("Dialog", Font.BOLD, 11));
		label_46.setBackground(SystemColor.controlHighlight);
		label_46.setBounds(1072, 112, 18, 21);
		frame.getContentPane().add(label_46);
		
		Label label_47 = new Label(" ");
		label_47.setFont(new Font("Dialog", Font.BOLD, 10));
		label_47.setBackground(SystemColor.controlHighlight);
		label_47.setBounds(992, 128, 85, 22);
		frame.getContentPane().add(label_47);
		
		Label label_48 = new Label(" ");
		label_48.setFont(new Font("Dialog", Font.BOLD, 11));
		label_48.setBackground(SystemColor.controlHighlight);
		label_48.setBounds(1081, 128, 28, 22);
		frame.getContentPane().add(label_48);
		
		Label label_49 = new Label("");
		label_49.setBackground(SystemColor.controlHighlight);
		label_49.setBounds(992, 78, 117, 75);
		frame.getContentPane().add(label_49);
		
		Label label_50 = new Label(" ");
		label_50.setFont(new Font("Dialog", Font.BOLD, 13));
		label_50.setBackground(SystemColor.controlHighlight);
		label_50.setBounds(419, 185, 52, 22);
		frame.getContentPane().add(label_50);
		
		Label label_51 = new Label(" ");
		label_51.setFont(new Font("Dialog", Font.BOLD, 13));
		label_51.setBackground(SystemColor.controlHighlight);
		label_51.setBounds(477, 185, 37, 22);
		frame.getContentPane().add(label_51);
		
		Label label_52 = new Label(" ");
		label_52.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_52.setBackground(SystemColor.controlHighlight);
		label_52.setBounds(407, 213, 64, 21);
		frame.getContentPane().add(label_52);
		
		Label label_53 = new Label(" ");
		label_53.setFont(new Font("Dialog", Font.BOLD, 11));
		label_53.setBackground(SystemColor.controlHighlight);
		label_53.setBounds(477, 213, 29, 21);
		frame.getContentPane().add(label_53);
		
		Label label_54 = new Label(" ");
		label_54.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_54.setBackground(SystemColor.controlHighlight);
		label_54.setBounds(407, 230, 86, 22);
		frame.getContentPane().add(label_54);
		
		Label label_55 = new Label(" ");
		label_55.setFont(new Font("Dialog", Font.BOLD, 11));
		label_55.setBackground(SystemColor.controlHighlight);
		label_55.setBounds(492, 230, 30, 22);
		frame.getContentPane().add(label_55);
		
		Label label_56 = new Label("");
		label_56.setBackground(SystemColor.controlHighlight);
		label_56.setBounds(407, 180, 115, 72);
		frame.getContentPane().add(label_56);
		
		Label label_57 = new Label("");
		label_57.setFont(new Font("Dialog", Font.BOLD, 13));
		label_57.setBackground(SystemColor.controlHighlight);
		label_57.setBounds(557, 185, 52, 22);
		frame.getContentPane().add(label_57);
		
		Label label_58 = new Label("");
		label_58.setFont(new Font("Dialog", Font.BOLD, 13));
		label_58.setBackground(SystemColor.controlHighlight);
		label_58.setBounds(615, 185, 37, 22);
		frame.getContentPane().add(label_58);
		
		Label label_59 = new Label(" ");
		label_59.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_59.setBackground(SystemColor.controlHighlight);
		label_59.setBounds(557, 213, 64, 21);
		frame.getContentPane().add(label_59);
		
		Label label_60 = new Label("");
		label_60.setFont(new Font("Dialog", Font.BOLD, 11));
		label_60.setBackground(SystemColor.controlHighlight);
		label_60.setBounds(625, 213, 29, 21);
		frame.getContentPane().add(label_60);
		
		Label label_61 = new Label("");
		label_61.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_61.setBackground(SystemColor.controlHighlight);
		label_61.setBounds(547, 230, 86, 22);
		frame.getContentPane().add(label_61);
		
		Label label_62 = new Label("");
		label_62.setFont(new Font("Dialog", Font.BOLD, 11));
		label_62.setBackground(SystemColor.controlHighlight);
		label_62.setBounds(635, 230, 29, 22);
		frame.getContentPane().add(label_62);
		
		Label label_63 = new Label("");
		label_63.setBackground(SystemColor.controlHighlight);
		label_63.setBounds(547, 180, 117, 72);
		frame.getContentPane().add(label_63);
		
		Label label_64 = new Label("");
		label_64.setFont(new Font("Dialog", Font.BOLD, 13));
		label_64.setBackground(SystemColor.controlHighlight);
		label_64.setBounds(705, 185, 52, 22);
		frame.getContentPane().add(label_64);
		
		Label label_65 = new Label("");
		label_65.setFont(new Font("Dialog", Font.BOLD, 13));
		label_65.setBackground(SystemColor.controlHighlight);
		label_65.setBounds(758, 185, 37, 22);
		frame.getContentPane().add(label_65);
		
		Label label_66 = new Label(" ");
		label_66.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_66.setBackground(SystemColor.controlHighlight);
		label_66.setBounds(693, 213, 64, 21);
		frame.getContentPane().add(label_66);
		
		Label label_67 = new Label(" ");
		label_67.setFont(new Font("Dialog", Font.BOLD, 11));
		label_67.setBackground(SystemColor.controlHighlight);
		label_67.setBounds(758, 213, 29, 21);
		frame.getContentPane().add(label_67);
		
		Label label_68 = new Label("");
		label_68.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 10));
		label_68.setBackground(SystemColor.controlHighlight);
		label_68.setBounds(692, 230, 86, 22);
		frame.getContentPane().add(label_68);
		
		Label label_69 = new Label("");
		label_69.setFont(new Font("Dialog", Font.BOLD, 11));
		label_69.setBackground(SystemColor.controlHighlight);
		label_69.setBounds(777, 230, 31, 22);
		frame.getContentPane().add(label_69);
		
		Label label_70 = new Label("");
		label_70.setBackground(SystemColor.controlHighlight);
		label_70.setBounds(692, 180, 122, 72);
		frame.getContentPane().add(label_70);
		

		/*fcfs = new JButton("fcfs");
		fcfs.setBounds(156, 286, 74, 25);
		fcfs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//float avgwt=values[0];
				fcfs_result.setText("hello");
			}
		});*/
		btnGenerateInput = new JButton("generate input");
		btnGenerateInput.setBounds(372, 27, 150, 25);
		btnGenerateInput.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//values=call();
				
				Random rand=new Random();
				 n=rand.nextInt(10)+1;
				int i;float p,q,r,s;
				 k=n;
				 System.out.println("n value"+n);
				inp_table=new String[n][4];
				/* for(i=0;i<10;i++)
					{
						dtm.addRow(new Object[]{"data","data","data","data"});
					}*/
					int id[]=new int[n];
				 at=new int[n];
				 bt=new int[n];
				 at1=new int[n];
				 bt1=new int[n];
				int pt[]=new int[n];
				 at2=new int[n];
				 bt2=new int[n];
				 at3=new int[n];
				 bt3=new int[n];
				 at4=new int[n];
				 bt4=new int[n];
				 at5=new int[n];
				 bt5=new int[n];
				for(i=0;i<n;i++)
				{
					at[i]=rand.nextInt(10)+1;
					bt[i]=rand.nextInt(10)+1;
					pt[i]=rand.nextInt(10)+1;
					id[i]=i;
					at1[i]=at[i];
					bt1[i]=bt[i];
					at2[i]=at[i];
					bt2[i]=bt[i];
					at3[i]=at[i];
					bt3[i]=bt[i];
					at4[i]=at[i];
					bt4[i]=bt[i];
					at5[i]=at[i];
					bt5[i]=bt[i];
					inp_table[i][0]=String.valueOf(id[i]);
					inp_table[i][1]=String.valueOf(at[i]);
					inp_table[i][2]=String.valueOf(bt[i]);
					inp_table[i][3]=String.valueOf(pt[i]);
					
					String header[]=	{"id","arrival_time","burst_time","prioity"};
					tb=new JTable(inp_table,header);
					scrollPane1 = new JScrollPane(tb);
					//scrollPane1.setBounds(857, 185, 292, 207);
					scrollPane1.setBounds(857, 185, 345, 207);
					frame.getContentPane().add(scrollPane1);
				}
				scheduling c=new scheduling();
				 n1=n;
				int n2=n;
				int n3=n;
				int n4=n;
				int n5=n;
				
				//q=c.SJF(n2,at2,bt2);
				//r=c.Round(n3,at3,bt3);
				//s=c.presjf(n4,at4,bt4);
				//float t=c.priority(n5,at5, bt5);
				//System.out.println("priority "+s);
				//float values[]=new float[3];
				//values[0]=p;
				//values[1]=q;
				//values[2]=r;
				//values[3]=s;
				//values[4]=t;
			}
		});
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(btnGenerateInput);
		
		
		JButton btnRr = new JButton("RR");
		btnRr.setBounds(104, 313, 98, 25);
		btnRr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				float k=values[2];
				

				scheduling ss=new scheduling();
				float r=ss.Round(n,at3,bt3);
				//System.out.println(p);
				rr_result.setText(String.valueOf(r));
				if(n==1)
				{
					lbl_1.setIcon(new ImageIcon(" "));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(SystemColor.controlHighlight);
					 label_7.setText(" ");
					label_7.setBackground(SystemColor.controlHighlight);
					label_8.setText(" ");
					label_8.setBackground(SystemColor.controlHighlight);
					label_9.setText(" ");
					label_9.setBackground(SystemColor.controlHighlight);
					label_10.setText(" ");
					label_10.setBackground(SystemColor.controlHighlight);
					label_11.setText(" ");
					label_11.setBackground(SystemColor.controlHighlight);
					label_12.setText(" ");
					label_12.setBackground(SystemColor.controlHighlight);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==2)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==3)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==4)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==5)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[3]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==6)
				{


					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id11[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(at3[ss.id11[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct11[ss.id11[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==7)
				{



					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));



					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id11[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(at3[ss.id11[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct11[ss.id11[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);		
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id11[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(at3[ss.id11[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct11[ss.id11[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==8)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id11[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(at3[ss.id11[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct11[ss.id11[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);		
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id11[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(at3[ss.id11[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct11[ss.id11[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id11[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(at3[ss.id11[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct11[ss.id11[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}

				if(n==9)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id11[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(at3[ss.id11[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct11[ss.id11[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);		
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id11[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(at3[ss.id11[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct11[ss.id11[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id11[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(at3[ss.id11[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct11[ss.id11[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id11[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(at3[ss.id11[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct11[ss.id11[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==10)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					
					label_1.setText(String.valueOf(ss.id11[0]));
					label_3.setText(String.valueOf(at3[ss.id11[0]]));
					label_5.setText(String.valueOf(ss.ct11[ss.id11[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id11[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(at3[ss.id11[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct11[ss.id11[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id11[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(at3[ss.id11[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct11[ss.id11[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(at3[ss.id11[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct11[ss.id11[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id11[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					

					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id11[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(at3[ss.id11[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct11[ss.id11[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id11[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(at3[ss.id11[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct11[ss.id11[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);		
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id11[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(at3[ss.id11[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct11[ss.id11[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id11[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(at3[ss.id11[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct11[ss.id11[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id11[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(at3[ss.id11[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct11[ss.id11[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					label_70.setBackground(Color.LIGHT_GRAY);
					 label_64.setText("Process");
					label_64.setBackground(Color.LIGHT_GRAY);
					label_65.setText(String.valueOf(ss.id11[9]));
					label_65.setBackground(Color.LIGHT_GRAY);
					label_66.setText("Arrival Time");
					label_66.setBackground(Color.LIGHT_GRAY);
					label_67.setText(String.valueOf(at3[ss.id11[9]]));
					label_67.setBackground(Color.LIGHT_GRAY);
					label_68.setText("Completion Time");
					label_68.setBackground(Color.LIGHT_GRAY);
					label_69.setText(String.valueOf(ss.ct11[ss.id11[9]]));
					label_69.setBackground(Color.LIGHT_GRAY);
					
				}
			}
		
		});
		frame.getContentPane().add(btnRr);
		
		rr_result = new JTextField();
		rr_result.setBounds(104, 349, 98, 49);
		frame.getContentPane().add(rr_result);
		rr_result.setColumns(10);
		
	
		
		fcfs = new JButton("fcfs");
		fcfs.setBounds(252, 313, 74, 25);
		fcfs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				scheduling ss=new scheduling();
				//float avgwt=values[0];
				float p=ss.FCFS(n,at1,bt1);
				//System.out.println(p);
				fcfs_result.setText(String.valueOf(p));
				if(n==1)
				{
					lbl_1.setIcon(new ImageIcon(" "));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(SystemColor.controlHighlight);
					 label_7.setText(" ");
					label_7.setBackground(SystemColor.controlHighlight);
					label_8.setText(" ");
					label_8.setBackground(SystemColor.controlHighlight);
					label_9.setText(" ");
					label_9.setBackground(SystemColor.controlHighlight);
					label_10.setText(" ");
					label_10.setBackground(SystemColor.controlHighlight);
					label_11.setText(" ");
					label_11.setBackground(SystemColor.controlHighlight);
					label_12.setText(" ");
					label_12.setBackground(SystemColor.controlHighlight);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==2)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==3)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==4)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));


					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==5)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));


					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].id));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].id));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==6)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].at));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.s[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.s[5].at));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.s[5].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==7)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].at));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.s[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.s[5].at));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.s[5].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.s[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.s[6].at));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.s[6].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==8)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].at));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.s[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.s[5].at));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.s[5].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.s[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.s[6].at));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.s[6].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.s[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.s[7].at));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.s[7].ct));
					label_55.setBackground(Color.LIGHT_GRAY);

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}

				if(n==9)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].at));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.s[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.s[5].at));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.s[5].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.s[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.s[6].at));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.s[6].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.s[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.s[7].at));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.s[7].ct));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.s[8].id));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.s[8].at));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.s[8].ct));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==10)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));

					label_1.setText(String.valueOf(ss.s[0].id));
					label_3.setText(String.valueOf(ss.s[0].at));
					label_5.setText(String.valueOf(ss.s[0].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.s[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.s[1].at));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.s[1].ct));
					label_12.setBackground(Color.LIGHT_GRAY);				
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.s[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.s[2].at));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.s[2].ct));
					label_19.setBackground(Color.LIGHT_GRAY);				
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.s[3].at));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.s[3].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.s[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.s[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.s[4].at));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.s[4].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.s[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.s[5].at));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.s[5].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.s[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.s[6].at));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.s[6].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.s[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.s[7].at));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.s[7].ct));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.s[8].id));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.s[8].at));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.s[8].ct));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					label_70.setBackground(Color.LIGHT_GRAY);
					 label_64.setText("Process");
					label_64.setBackground(Color.LIGHT_GRAY);
					label_65.setText(String.valueOf(ss.s[9].id));
					label_65.setBackground(Color.LIGHT_GRAY);
					label_66.setText("Arrival Time");
					label_66.setBackground(Color.LIGHT_GRAY);
					label_67.setText(String.valueOf(ss.s[9].at));
					label_67.setBackground(Color.LIGHT_GRAY);
					label_68.setText("Completion Time");
					label_68.setBackground(Color.LIGHT_GRAY);
					label_69.setText(String.valueOf(ss.s[9].ct));
					label_69.setBackground(Color.LIGHT_GRAY);
					
				}
			}
		});
		frame.getContentPane().add(fcfs);
		
		fcfs_result = new JTextField();
		fcfs_result.setBounds(237, 349, 91, 49);
		frame.getContentPane().add(fcfs_result);
		fcfs_result.setColumns(10);
		
		//float avg=SJF();
		btnNewButton = new JButton("sjf");
		btnNewButton.setBounds(372, 313, 98, 25);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				scheduling ss=new scheduling();
				int hh[]=new int[3];
				//hh[0]=ss.ct[0];
				float avg=values[1];
			   float q=ss.SJF(n,at2,bt2);
				//System.out.println("$$$"+ss.prid1[0]);
				sjf_result.setText(String.valueOf(q));
				
				if(n==1)
				{
					lbl_1.setIcon(new ImageIcon(" "));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(SystemColor.controlHighlight);
					 label_7.setText(" ");
					label_7.setBackground(SystemColor.controlHighlight);
					label_8.setText(" ");
					label_8.setBackground(SystemColor.controlHighlight);
					label_9.setText(" ");
					label_9.setBackground(SystemColor.controlHighlight);
					label_10.setText(" ");
					label_10.setBackground(SystemColor.controlHighlight);
					label_11.setText(" ");
					label_11.setBackground(SystemColor.controlHighlight);
					label_12.setText(" ");
					label_12.setBackground(SystemColor.controlHighlight);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==2)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==3)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
				lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
				lbl_3.setIcon(new ImageIcon(" "));
				lbl_4.setIcon(new ImageIcon(" "));
				lbl_5.setIcon(new ImageIcon(" "));
				lbl_6.setIcon(new ImageIcon(" "));
				lbl_7.setIcon(new ImageIcon(" "));
				lbl_8.setIcon(new ImageIcon(" "));
				lbl_9.setIcon(new ImageIcon(" "));
					
					
				label_1.setText(String.valueOf(ss.id[0]));
				label_3.setText(String.valueOf(ss.at[ss.id[0]]));
				label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
				label_1.setBackground(Color.LIGHT_GRAY);
				label_3.setBackground(Color.LIGHT_GRAY);
				label_5.setBackground(Color.LIGHT_GRAY);
				label_6.setBackground(Color.LIGHT_GRAY);
				label.setText("Process");
				label_2.setText("Arrival Time");
				label_4.setText("Completion Time");
				label.setBackground(Color.LIGHT_GRAY);
				label_2.setBackground(Color.LIGHT_GRAY);
				label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==4)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					

					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==5)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));


					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==6)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at[ss.id[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct[ss.id[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==7)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at[ss.id[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct[ss.id[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at[ss.id[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct[ss.id[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==8)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at[ss.id[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct[ss.id[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at[ss.id[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct[ss.id[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at[ss.id[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct[ss.id[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}

				if(n==9)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at[ss.id[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct[ss.id[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at[ss.id[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct[ss.id[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at[ss.id[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct[ss.id[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.at[ss.id[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct[ss.id[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==10)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));

					label_1.setText(String.valueOf(ss.id[0]));
					label_3.setText(String.valueOf(ss.at[ss.id[0]]));
					label_5.setText(String.valueOf(ss.ct[ss.id[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at[ss.id[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct[ss.id[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at[ss.id[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct[ss.id[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at[ss.id[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct[ss.id[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at[ss.id[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct[ss.id[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at[ss.id[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct[ss.id[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at[ss.id[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct[ss.id[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at[ss.id[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct[ss.id[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.at[ss.id[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct[ss.id[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(Color.LIGHT_GRAY);
					 label_64.setText("Process");
					label_64.setBackground(Color.LIGHT_GRAY);
					label_65.setText(String.valueOf(ss.id[9]));
					label_65.setBackground(Color.LIGHT_GRAY);
					label_66.setText("Arrival Time");
					label_66.setBackground(Color.LIGHT_GRAY);
					label_67.setText(String.valueOf(ss.at[ss.id[9]]));
					label_67.setBackground(Color.LIGHT_GRAY);
					label_68.setText("Completion Time");
					label_68.setBackground(Color.LIGHT_GRAY);
					label_69.setText(String.valueOf(ss.ct[ss.id[9]]));
					label_69.setBackground(Color.LIGHT_GRAY);
					
				}
				
				
			}
		});
		frame.getContentPane().add(btnNewButton);
		
		sjf_result = new JTextField();
		sjf_result.setBounds(372, 349, 98, 49);
		frame.getContentPane().add(sjf_result);
		sjf_result.setColumns(10);
		prior = new JTextField();
		prior.setBounds(523, 349, 98, 49);
		JButton presjf = new JButton("presjf");
		presjf.setBounds(523, 313, 98, 25);
		presjf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//	float avg_wt=values[3];
				//System.out.println(values[3]+" "+avg_wt);
				
				scheduling ss=new scheduling();
				float s=ss.presjf(n,at4,bt4);
				//System.out.println(p);
				prior.setText(String.valueOf(s));
				if(n==1)
				{
					lbl_1.setIcon(new ImageIcon(" "));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					
					label_13.setBackground(SystemColor.controlHighlight);
					 label_7.setText(" ");
					label_7.setBackground(SystemColor.controlHighlight);
					label_8.setText(" ");
					label_8.setBackground(SystemColor.controlHighlight);
					label_9.setText(" ");
					label_9.setBackground(SystemColor.controlHighlight);
					label_10.setText(" ");
					label_10.setBackground(SystemColor.controlHighlight);
					label_11.setText(" ");
					label_11.setBackground(SystemColor.controlHighlight);
					label_12.setText(" ");
					label_12.setBackground(SystemColor.controlHighlight);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==2)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==3)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					
					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==4)
				{
					

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==5)
				{


					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));


					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==6)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.op[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.op[ss.op[5].id].AT));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.op[ss.op[5].id].ct));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==7)
				{


					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.op[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.op[ss.op[5].id].AT));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.op[ss.op[5].id].ct));
					label_41.setBackground(Color.LIGHT_GRAY);				
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.op[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.op[ss.op[6].id].AT));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.op[ss.op[6].id].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==8)
				{


					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));

					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));


					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.op[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.op[ss.op[5].id].AT));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.op[ss.op[5].id].ct));
					label_41.setBackground(Color.LIGHT_GRAY);				
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.op[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.op[ss.op[6].id].AT));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.op[ss.op[6].id].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.op[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.op[ss.op[7].id].AT));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.op[ss.op[7].id].ct));
					label_55.setBackground(Color.LIGHT_GRAY);

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}

				if(n==9)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.op[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.op[ss.op[5].id].AT));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.op[ss.op[5].id].ct));
					label_41.setBackground(Color.LIGHT_GRAY);				
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.op[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.op[ss.op[6].id].AT));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.op[ss.op[6].id].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.op[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.op[ss.op[7].id].AT));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.op[ss.op[7].id].ct));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.op[8].id));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.op[ss.op[8].id].AT));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.op[ss.op[8].id].ct));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==10)
				{


					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));


					label_1.setText(String.valueOf(ss.op[0].id));
					label_3.setText(String.valueOf(ss.op[ss.op[0].id].AT));
					label_5.setText(String.valueOf(ss.op[ss.op[0].id].ct));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.op[1].id));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.op[ss.op[1].id].AT));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.op[ss.op[1].id].ct));
					label_12.setBackground(Color.LIGHT_GRAY);			
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.op[2].id));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.op[ss.op[2].id].AT));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.op[ss.op[2].id].ct));
					label_19.setBackground(Color.LIGHT_GRAY);
								
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.op[ss.op[3].id].AT));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.op[ss.op[3].id].ct));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.op[3].id));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.op[4].id));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.op[ss.op[4].id].AT));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.op[ss.op[4].id].ct));
					label_34.setBackground(Color.LIGHT_GRAY);
					
					
					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.op[5].id));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.op[ss.op[5].id].AT));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.op[ss.op[5].id].ct));
					label_41.setBackground(Color.LIGHT_GRAY);				
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.op[6].id));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.op[ss.op[6].id].AT));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.op[ss.op[6].id].ct));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.op[7].id));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.op[ss.op[7].id].AT));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.op[ss.op[7].id].ct));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.op[8].id));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.op[ss.op[8].id].AT));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.op[ss.op[8].id].ct));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(Color.LIGHT_GRAY);
					 label_64.setText("Process");
					label_64.setBackground(Color.LIGHT_GRAY);
					label_65.setText(String.valueOf(ss.op[9].id));
					label_65.setBackground(Color.LIGHT_GRAY);
					label_66.setText("Arrival Time");
					label_66.setBackground(Color.LIGHT_GRAY);
					label_67.setText(String.valueOf(ss.op[ss.op[9].id].AT));
					label_67.setBackground(Color.LIGHT_GRAY);
					label_68.setText("Completion Time");
					label_68.setBackground(Color.LIGHT_GRAY);
					label_69.setText(String.valueOf(ss.op[ss.op[9].id].ct));
					label_69.setBackground(Color.LIGHT_GRAY);
					
				}
			}
		});
		frame.getContentPane().add(presjf);
		frame.getContentPane().add(prior);
		prior.setColumns(10);
		
		btnPriority = new JButton("priority");
		btnPriority.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				scheduling ss=new scheduling();
				float t=ss.priority(n,at5, bt5);
				prior_res.setText(String.valueOf(t));
				if(n==1)
				{
					lbl_1.setIcon(new ImageIcon(" "));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(SystemColor.controlHighlight);
					 label_7.setText(" ");
					label_7.setBackground(SystemColor.controlHighlight);
					label_8.setText(" ");
					label_8.setBackground(SystemColor.controlHighlight);
					label_9.setText(" ");
					label_9.setBackground(SystemColor.controlHighlight);
					label_10.setText(" ");
					label_10.setBackground(SystemColor.controlHighlight);
					label_11.setText(" ");
					label_11.setBackground(SystemColor.controlHighlight);
					label_12.setText(" ");
					label_12.setBackground(SystemColor.controlHighlight);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==2)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon(" "));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					label_20.setBackground(SystemColor.controlHighlight);
					 label_14.setText(" ");
					label_14.setBackground(SystemColor.controlHighlight);
					label_15.setText(" ");
					label_15.setBackground(SystemColor.controlHighlight);
					label_16.setText(" ");
					label_16.setBackground(SystemColor.controlHighlight);
					label_17.setText(" ");
					label_17.setBackground(SystemColor.controlHighlight);
					label_18.setText(" ");
					label_18.setBackground(SystemColor.controlHighlight);
					label_19.setText(" ");
					label_19.setBackground(SystemColor.controlHighlight);
					
					

					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==3)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon(" "));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
					
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_26.setBackground(SystemColor.controlHighlight);
					 label_21.setText(" ");
					label_21.setBackground(SystemColor.controlHighlight);
					label_22.setText(" ");
					label_22.setBackground(SystemColor.controlHighlight);
					label_23.setText(" ");
					label_23.setBackground(SystemColor.controlHighlight);
					label_24.setText(" ");
					label_24.setBackground(SystemColor.controlHighlight);
					label_25.setText(" ");
					label_25.setBackground(SystemColor.controlHighlight);
					label_27.setText(" ");
					label_27.setBackground(SystemColor.controlHighlight);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==4)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon(" "));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);
					
					
					


					label_35.setBackground(SystemColor.controlHighlight);
					 label_29.setText(" ");
					label_29.setBackground(SystemColor.controlHighlight);
					label_30.setText(" ");
					label_30.setBackground(SystemColor.controlHighlight);
					label_31.setText(" ");
					label_31.setBackground(SystemColor.controlHighlight);
					label_32.setText(" ");
					label_32.setBackground(SystemColor.controlHighlight);
					label_33.setText(" ");
					label_33.setBackground(SystemColor.controlHighlight);
					label_34.setText(" ");
					label_34.setBackground(SystemColor.controlHighlight);




					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==5)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon(" "));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(SystemColor.controlHighlight);
					 label_36.setText(" ");
					label_36.setBackground(SystemColor.controlHighlight);
					label_37.setText(" ");
					label_37.setBackground(SystemColor.controlHighlight);
					label_38.setText(" ");
					label_38.setBackground(SystemColor.controlHighlight);
					label_39.setText(" ");
					label_39.setBackground(SystemColor.controlHighlight);
					label_40.setText(" ");
					label_40.setBackground(SystemColor.controlHighlight);
					label_41.setText(" ");
					label_41.setBackground(SystemColor.controlHighlight);
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==6)
				{
					
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon(" "));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id22[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at22[ss.id22[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct22[ss.id22[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_49.setBackground(SystemColor.controlHighlight);
					 label_43.setText(" ");
					label_43.setBackground(SystemColor.controlHighlight);
					label_44.setText(" ");
					label_44.setBackground(SystemColor.controlHighlight);
					label_45.setText(" ");
					label_45.setBackground(SystemColor.controlHighlight);
					label_46.setText(" ");
					label_46.setBackground(SystemColor.controlHighlight);
					label_47.setText(" ");
					label_47.setBackground(SystemColor.controlHighlight);
					label_48.setText(" ");
					label_48.setBackground(SystemColor.controlHighlight);
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==7)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon(" "));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id22[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at22[ss.id22[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct22[ss.id22[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id22[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at22[ss.id22[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct22[ss.id22[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					
					
					label_56.setBackground(SystemColor.controlHighlight);
					 label_50.setText(" ");
					label_50.setBackground(SystemColor.controlHighlight);
					label_51.setText(" ");
					label_51.setBackground(SystemColor.controlHighlight);
					label_52.setText(" ");
					label_52.setBackground(SystemColor.controlHighlight);
					label_53.setText(" ");
					label_53.setBackground(SystemColor.controlHighlight);
					label_54.setText(" ");
					label_54.setBackground(SystemColor.controlHighlight);
					label_55.setText(" ");
					label_55.setBackground(SystemColor.controlHighlight);
					
					

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==8)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon(" "));
					lbl_9.setIcon(new ImageIcon(" "));

					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id22[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at22[ss.id22[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct22[ss.id22[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id22[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at22[ss.id22[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct22[ss.id22[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id22[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at22[ss.id22[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct22[ss.id22[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);

					label_63.setBackground(SystemColor.controlHighlight);
					 label_57.setText(" ");
					label_57.setBackground(SystemColor.controlHighlight);
					label_58.setText(" ");
					label_58.setBackground(SystemColor.controlHighlight);
					label_59.setText(" ");
					label_59.setBackground(SystemColor.controlHighlight);
					label_60.setText(" ");
					label_60.setBackground(SystemColor.controlHighlight);
					label_61.setText(" ");
					label_61.setBackground(SystemColor.controlHighlight);
					label_62.setText(" ");
					label_62.setBackground(SystemColor.controlHighlight);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}

				if(n==9)
				{

					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon(" "));
					
					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id22[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at22[ss.id22[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct22[ss.id22[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id22[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at22[ss.id22[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct22[ss.id22[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id22[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at22[ss.id22[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct22[ss.id22[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id22[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.at22[ss.id22[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct22[ss.id22[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(SystemColor.controlHighlight);
					 label_64.setText(" ");
					label_64.setBackground(SystemColor.controlHighlight);
					label_65.setText(" ");
					label_65.setBackground(SystemColor.controlHighlight);
					label_66.setText(" ");
					label_66.setBackground(SystemColor.controlHighlight);
					label_67.setText(" ");
					label_67.setBackground(SystemColor.controlHighlight);
					label_68.setText(" ");
					label_68.setBackground(SystemColor.controlHighlight);
					label_69.setText(" ");
					label_69.setBackground(SystemColor.controlHighlight);
					
				}
				
				if(n==10)
				{
					lbl_1.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_2.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_3.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_4.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_5.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_6.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_7.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_8.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));
					lbl_9.setIcon(new ImageIcon("C:\\Users\\YUVARAJ\\Pictures\\r8arrw.png"));

					label_1.setText(String.valueOf(ss.id22[0]));
					label_3.setText(String.valueOf(ss.at22[ss.id22[0]]));
					label_5.setText(String.valueOf(ss.ct22[ss.id22[0]]));
					label_1.setBackground(Color.LIGHT_GRAY);
					label_3.setBackground(Color.LIGHT_GRAY);
					label_5.setBackground(Color.LIGHT_GRAY);
					label_6.setBackground(Color.LIGHT_GRAY);
					label.setText("Process");
					label_2.setText("Arrival Time");
					label_4.setText("Completion Time");
					label.setBackground(Color.LIGHT_GRAY);
					label_2.setBackground(Color.LIGHT_GRAY);
					label_4.setBackground(Color.LIGHT_GRAY);
				
					label_13.setBackground(Color.LIGHT_GRAY);
					 label_7.setText("Process");
					label_7.setBackground(Color.LIGHT_GRAY);
					label_8.setText(String.valueOf(ss.id22[1]));
					label_8.setBackground(Color.LIGHT_GRAY);
					label_9.setText("Arrival Time");
					label_9.setBackground(Color.LIGHT_GRAY);
					label_10.setText(String.valueOf(ss.at22[ss.id22[1]]));
					label_10.setBackground(Color.LIGHT_GRAY);
					label_11.setText("Completion Time");
					label_11.setBackground(Color.LIGHT_GRAY);
					label_12.setText(String.valueOf(ss.ct22[ss.id22[1]]));
					label_12.setBackground(Color.LIGHT_GRAY);
					
					
					
					label_20.setBackground(Color.LIGHT_GRAY);
					 label_14.setText("Process");
					label_14.setBackground(Color.LIGHT_GRAY);
					label_15.setText(String.valueOf(ss.id22[2]));
					label_15.setBackground(Color.LIGHT_GRAY);
					label_16.setText("Arrival Time");
					label_16.setBackground(Color.LIGHT_GRAY);
					label_17.setText(String.valueOf(ss.at22[ss.id22[2]]));
					label_17.setBackground(Color.LIGHT_GRAY);
					label_18.setText("Completion Time");
					label_18.setBackground(Color.LIGHT_GRAY);
					label_19.setText(String.valueOf(ss.ct22[ss.id22[2]]));
					label_19.setBackground(Color.LIGHT_GRAY);
					
					
					label_26.setBackground(Color.LIGHT_GRAY);
					 label_21.setText("Process");
					label_21.setBackground(Color.LIGHT_GRAY);
					label_22.setText("Arrival Time");
					label_22.setBackground(Color.LIGHT_GRAY);
					label_23.setText(String.valueOf(ss.at22[ss.id22[3]]));
					label_23.setBackground(Color.LIGHT_GRAY);
					label_24.setText("Completion Time");
					label_24.setBackground(Color.LIGHT_GRAY);
					label_25.setText(String.valueOf(ss.ct22[ss.id22[3]]));
					label_25.setBackground(Color.LIGHT_GRAY);
					label_27.setText(String.valueOf(ss.id22[3]));
					label_27.setBackground(Color.LIGHT_GRAY);					
					
					label_35.setBackground(Color.LIGHT_GRAY);
					 label_29.setText("Process");
					label_29.setBackground(Color.LIGHT_GRAY);
					label_30.setText(String.valueOf(ss.id22[4]));
					label_30.setBackground(Color.LIGHT_GRAY);
					label_31.setText("Arrival Time");
					label_31.setBackground(Color.LIGHT_GRAY);
					label_32.setText(String.valueOf(ss.at22[ss.id22[4]]));
					label_32.setBackground(Color.LIGHT_GRAY);
					label_33.setText("Completion Time");
					label_33.setBackground(Color.LIGHT_GRAY);
					label_34.setText(String.valueOf(ss.ct22[ss.id22[4]]));
					label_34.setBackground(Color.LIGHT_GRAY);

					label_42.setBackground(Color.LIGHT_GRAY);
					 label_36.setText("Process");
					label_36.setBackground(Color.LIGHT_GRAY);
					label_37.setText(String.valueOf(ss.id22[5]));
					label_37.setBackground(Color.LIGHT_GRAY);
					label_38.setText("Arrival Time");
					label_38.setBackground(Color.LIGHT_GRAY);
					label_39.setText(String.valueOf(ss.at22[ss.id22[5]]));
					label_39.setBackground(Color.LIGHT_GRAY);
					label_40.setText("Completion Time");
					label_40.setBackground(Color.LIGHT_GRAY);
					label_41.setText(String.valueOf(ss.ct22[ss.id22[5]]));
					label_41.setBackground(Color.LIGHT_GRAY);
					
					
					label_49.setBackground(Color.LIGHT_GRAY);
					 label_43.setText("Process");
					label_43.setBackground(Color.LIGHT_GRAY);
					label_44.setText(String.valueOf(ss.id22[6]));
					label_44.setBackground(Color.LIGHT_GRAY);
					label_45.setText("Arrival Time");
					label_45.setBackground(Color.LIGHT_GRAY);
					label_46.setText(String.valueOf(ss.at22[ss.id22[6]]));
					label_46.setBackground(Color.LIGHT_GRAY);
					label_47.setText("Completion Time");
					label_47.setBackground(Color.LIGHT_GRAY);
					label_48.setText(String.valueOf(ss.ct22[ss.id22[6]]));
					label_48.setBackground(Color.LIGHT_GRAY);
					
					
					label_56.setBackground(Color.LIGHT_GRAY);
					 label_50.setText("Process");
					label_50.setBackground(Color.LIGHT_GRAY);
					label_51.setText(String.valueOf(ss.id22[7]));
					label_51.setBackground(Color.LIGHT_GRAY);
					label_52.setText("Arrival Time");
					label_52.setBackground(Color.LIGHT_GRAY);
					label_53.setText(String.valueOf(ss.at22[ss.id22[7]]));
					label_53.setBackground(Color.LIGHT_GRAY);
					label_54.setText("Completion Time");
					label_54.setBackground(Color.LIGHT_GRAY);
					label_55.setText(String.valueOf(ss.ct22[ss.id22[7]]));
					label_55.setBackground(Color.LIGHT_GRAY);
					
					
					label_63.setBackground(Color.LIGHT_GRAY);
					 label_57.setText("Process");
					label_57.setBackground(Color.LIGHT_GRAY);
					label_58.setText(String.valueOf(ss.id22[8]));
					label_58.setBackground(Color.LIGHT_GRAY);
					label_59.setText("Arrival Time");
					label_59.setBackground(Color.LIGHT_GRAY);
					label_60.setText(String.valueOf(ss.at22[ss.id22[8]]));
					label_60.setBackground(Color.LIGHT_GRAY);
					label_61.setText("Completion Time");
					label_61.setBackground(Color.LIGHT_GRAY);
					label_62.setText(String.valueOf(ss.ct22[ss.id22[8]]));
					label_62.setBackground(Color.LIGHT_GRAY);
					
					
					label_70.setBackground(Color.LIGHT_GRAY);
					 label_64.setText("Process");
					label_64.setBackground(Color.LIGHT_GRAY);
					label_65.setText(String.valueOf(ss.id22[9]));
					label_65.setBackground(Color.LIGHT_GRAY);
					label_66.setText("Arrival Time");
					label_66.setBackground(Color.LIGHT_GRAY);
					label_67.setText(String.valueOf(ss.at22[ss.id22[9]]));
					label_67.setBackground(Color.LIGHT_GRAY);
					label_68.setText("Completion Time");
					label_68.setBackground(Color.LIGHT_GRAY);
					label_69.setText(String.valueOf(ss.ct22[ss.id22[9]]));
					label_69.setBackground(Color.LIGHT_GRAY);
					
				}
				
				
			}
		});
		btnPriority.setBounds(667, 313, 117, 25);
		frame.getContentPane().add(btnPriority);
		
		prior_res = new JTextField();
		prior_res.setBounds(667, 349, 114, 49);
		frame.getContentPane().add(prior_res);
		prior_res.setColumns(10);
		int i;
		
		
		
		//scrollPane1.setViewportView(tb);
		//DefaultTableModel dtm =new DefaultTableModel(0,0);
		//String header[]=	{"id","arrival_time","burst_time","prioity"};
		//dtm.setColumnIdentifiers(header);
			//tb.setModel(dtm);
		tb=new JTable();
		scrollPane1 = new JScrollPane(tb);
		scrollPane1.setBounds(857, 185, 345, 207);
		frame.getContentPane().add(scrollPane1);
			
			
				
			
		/*for(i=0;i<10;i++)
		{
			dtm.addRow(new Object[]{"data","data","data","data"});
		}*/
		
		
		


		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "SwingAction_1");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}