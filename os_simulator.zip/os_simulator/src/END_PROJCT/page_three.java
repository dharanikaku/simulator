package END_PROJCT;
//package org.jfree.chart.demo;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
//import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Rotation;


public class page_three extends ApplicationFrame{

    
	public JFrame frame=new JFrame();
	private static final long serialVersionUID = 1L;

    public page_three() {

        super("Comparision Of all page replacement");

        
        JPanel chartPanel = createChart();
        
       
        chartPanel.setPreferredSize(new java.awt.Dimension(100, 200));
        //setContentPane(chartPanel);
        frame.setBounds(100, 100, 640, 480);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add(chartPanel);
        frame.setVisible(true);

    }
    
    
    private PieDataset createSampleDataset() {
    	//disk_sec e=new disk_sec();
    	
        String p1="FIFO"+" - "+String.valueOf(page_first.fi);
        String p2="LRU"+" - "+String.valueOf(page_first.lr);
        String p3="OPTIMAL"+" - "+String.valueOf(page_first.op);
        String p4="SECOND"+" - "+String.valueOf(page_first.sec);
        
    	DefaultPieDataset result = new DefaultPieDataset();
    //System.out.println("%%%%% "+disk_sec.c1);
        result.setValue(p1, page_first.fi);
        result.setValue(p2, page_first.lr);
        result.setValue(p3, page_first.op);
        result.setValue(p4, page_first.sec);
        
        return result;
        
    }
    
    
   


	public JPanel createChart() {
    	
        
        PieDataset dataset=createSampleDataset();

        JFreeChart chart = ChartFactory.createPieChart3D(
            "Comparision of all disk algorithms",  // chart title
            dataset,                // data
            true,                   // include legend
            true,
            false
        );
        final PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        plot.setNoDataMessage("No data to display");
        return new ChartPanel(chart);
        
    }
    
   
    public void req() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	try {
					page_three window = new page_three();
					window.frame.setVisible(true);
					window.setVisible(true);
					//window.pack();
			        //RefineryUtilities.centerFrameOnScreen(window);
				} catch (Exception e) {
					e.printStackTrace();
				}
                
            }
        });
}
}