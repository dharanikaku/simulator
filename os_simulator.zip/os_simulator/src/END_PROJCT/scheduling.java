package END_PROJCT;

import java.util.*;

import java.util.concurrent.ThreadLocalRandom;


import END_PROJCT.scheduling.str;


public class scheduling {
	public int ct[];
	public int prid[];
	public int ct11[];
	public int id11[];
	public int id[];
	public int id22[];
	public int at[];
	public int at22[];
	public int ct22[];
	public str[] s;
	public pre[] op;
	public int prid1[];
	public int prid2[];
	public static int empty(int a[],int n)
	{
		int i,count=0;
		for (i=0;i<n;i++)
		{
			if(a[i]==0)
			{
				count=count+1;
			}
		}
		//System.out.println("count is "+count);
		if(count==n)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public float Round(int n,int at[],int bt[])
	{
		int i,j,cycles=0,count=0,time_quantum;
		float avg_wttime=0;
		//Scanner sc = new Scanner(System.in);
		Random r = new Random();
		
		//int n= r.nextInt(10)+1;
		//System.out.println("no of process = "+ n);
		//time_quantum=5;
		time_quantum=r.nextInt(10)+1;
		System.out.println("time quantum = "+ time_quantum);
		System.out.println("at"+"\t"+"bt");
		scheduling s= new scheduling();
		 id11=new int[n];
	    //int at[]= new int[n];
		//int bt[]=new int[n];
		ct11=new int[n];
		int tat[]=new int[n];
		int wt[]= new int[n];
		int emp[]= new int[n];
		int b[]=new int[n];
		
	
		for (i=0;i<n;i++)
		{
			//at[i]=r.nextInt(50);
			System.out.print(at[i]+"\t");
			//bt[i]=r.nextInt(50)+1;
			System.out.println(bt[i]);
			id11[i]=i;
			System.out.println(" id11 " +id11[i] + " i " + i );
		}
		
		//at=s.sort(at,n);
		//Arrays.sort(at);
		int temp,tem,tempt;
		for(i=0;i<n;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if (at[i]>at[j])
				{
					temp=at[i];
					at[i]=at[j];
					at[j]=temp;
					tem=bt[i];
					bt[i]=bt[j];
					bt[j]=tem;
					tempt=b[i];
					b[i]=b[j];
					b[j]=tempt;
					
				}
			}		
		}
		i=0;
		int k=empty(bt,n);
		//System.out.println(k);
		while(k==0)
		{
			k=empty(bt,n);
			for(i=0;i<n;i++)
			{	
				if(bt[i]!=0)
				{
					//System.out.println("processid "+ i);
					if(bt[i]<=time_quantum)
					{
						//ct[i]=ct[i]+bt[i];
						cycles=cycles+(bt[i]);
						bt[i]=0;
						ct11[i]=cycles;
						System.out.println("ct of "+i + " is "+ ct11[i] );
					}
					else if(bt[i]>time_quantum)
					{
						//ct[i]=ct[i]+time_quantum;
						bt[i]=bt[i]-time_quantum;
						cycles=cycles+(time_quantum);
						ct11[i]=cycles;
						System.out.println("ct of "+i + " is "+ ct11[i] );
						//System.out.println("ct of "+(i+1)+" is "+cycles);
					}
				}
			}
		}
		//System.out.println(k);
		for(i=0;i<n;i++)
		{
			tat[i]=ct11[i]-at[i];
		}
		for(i=0;i<n;i++)
		{
			wt[i]=tat[i]-b[i];
			avg_wttime=avg_wttime+(wt[i]);
		}
		
		for(i=0;i<n-1;i++)
		{
			for(j=i+1;j<n;j++)
			{
				if(ct11[i]>ct11[j])
				{
					temp=id11[i];
					id11[i]=id11[j];
					id11[j]=temp;
					
				}
			}
		}
		//float avg=avg_wttime/n;
		avg_wttime=avg_wttime/n;
		System.out.println("avg waiting time is "+avg_wttime);
		return avg_wttime;
	}
	
	
	class str
	{
		int at;
		int bt;
		int tat;
		int ct;
		int wt;
		int id;
	}

	public  float FCFS(int n,int[] at,int bt[])
		{
			;int i,j;
			float avgwt=0;
			str t=new str();
			s=new str[100];
		
			for(i=0;i<n;i++)
			{
				//System.out.println(art[i]+" "+brt[i]+"fcfs");
			}
			for(i=0;i<n;i++)
			{
				s[i]=new str();
			}
			
			for(i=0;i<n;i++)
			{
				s[i].at=at[i];//rand.nextInt(10)+1;
				s[i].bt=bt[i];//rand.nextInt(10)+1;
				s[i].id=i;
				s[i].ct=0;
			}
			int z=0;
			for(i=0;i<n-1;i++)
			{
			for(j=i+1;j<n;j++)
			{
				if (s[i].at>s[j].at)
				{
					t=s[i];
					s[i]=s[j];
					s[j]=t;
				}
			}
			}
			
			int prev=1;
			for(i=0;i<n;i++)
			{
				if (s[prev].ct>=s[i].at)	
				{
					s[i].ct=s[prev].ct+s[i].bt;
					
				}
				else	
				{
					s[i].ct=s[i].at+s[i].bt;
				}
				s[i].tat=s[i].ct-s[i].at;
				s[i].wt=s[i].tat-s[i].bt;
				avgwt=avgwt+s[i].wt;
				prev=i;
			}
			avgwt=avgwt/n;
			
			for(i=0;i<n-1;i++)
			{
			for(j=i+1;j<n;j++)
			{
				if (s[i].ct>s[j].ct)
				{
					t=s[i];
					s[i]=s[j];
					s[j]=t;
					
				}
			}
			}
			for(i=0;i<n;i++)
			{
				System.out.println(s[i].id+" "+s[i].ct+" "+s[i].at);
			}	
			System.out.println("average waiting time:"+avgwt);
			return avgwt;
			//return avgwt;
		}

	
	public float SJF(int n1,int[] at1,int bt1[])
			{
			int i,j,n,temp;
			n=n1;
			 at=new int[n];
			int[] bt=new int[n];
			 ct=new int[n];
			int[] tat=new int[n];
			int[] wt=new int[n];
			int[] status=new int[n];
			 id=new int[n];
			float avgwt=0; 
			 
			for(i=0;i<n;i++)
			{
				at[i]=at1[i];
				bt[i]=bt1[i];
				status[i]=0;
				ct[i]=0;
				id[i]=i;
			}
			int present_ind;int prev_ind=0;
			int z1=0;
			for(i=0;i<n;i++)
			{
				present_ind=findMin(bt,status,at,ct,prev_ind,n);
				System.out.println("i"+present_ind);
				status[present_ind]=1;
				if(ct[prev_ind]>=at[present_ind])
				{
					ct[present_ind]=ct[prev_ind]+bt[present_ind];
				}
				else
				{
					ct[present_ind]=at[present_ind]+bt[present_ind];
				}
				System.out.println("ct "+ct[present_ind]);
				tat[present_ind]=ct[present_ind]-at[present_ind];
				wt[present_ind]=tat[present_ind]-bt[present_ind];
				avgwt=avgwt+wt[present_ind];
				prev_ind=present_ind;
		
			}
			for(i=0;i<n-1;i++)
			{
				for(j=i+1;j<n;j++)
				{
					if(ct[i]>ct[j])
					{
						temp=id[i];
						id[i]=id[j];
						id[j]=temp;
						
					}
				}
			}
			avgwt=avgwt/n;
			
			//System.out.println(avgwt);
			return avgwt;
	}
			
	public static int findMin(int[] value,int[] status1,int[] atime,int[] comp_time,int before,int len)
		{
			boolean flag=false,flag1=false;int min=0,min_at=0,index=0,count=0,j=0,i;
			for(i=0;i<len;i++)
			{
				if(flag==false&&status1[i]==0&&atime[i]<=comp_time[before])
				{
					min=value[i];
					index=i;
					flag=true;
				}
				else
				{
					if((status1[i]==0)&&(atime[i]<=comp_time[before])&&value[i]<min)
						{
							flag1=true;
							min=value[i];
							index=i;
						}
				}
			}
			if(flag==false)
			{
				
				boolean flagi=false;
				for(i=0;i<len;i++)
				{
					if(status1[i]==0)
					{
						if(flagi==false)
						{	
							min=atime[i];
							index=i;
							flagi=true;
						}
					
						else
						{
							if(atime[i]<=min)
							{
								
									min=atime[i];
									index=i;
									
							}							
						}	
					}
				
				}
			}
			return index;
	}





	
	class pre
	{
		float Tat;
		float WT;
		int AT;
		int id;
		int BT;
		float ct;
		int temp;
	}
	
	public  float presjf(int n,int AT[],int BT[])
	{
	
	int A=0;int l,j,tim,count=0,small,index=0,sum=0,pr;
		float WT=0,Tat=0,end;
		float avg_wt,avg_tat;
		
		op=new pre[n+1];
		
		for(int i=0;i<n;i++)
		{
			System.out.println(AT[i]+" "+BT[i]+"presjf");
		}
		int temp[]=new int[n];
		for(int m=0;m<n;m++)
		{
			op[m]=new pre();
		}
		for(int i=0;i<n;i++)
		{
			//op[i].pr=i;
			op[i].BT=BT[i];
			op[i].AT=AT[i];
			op[i].temp=BT[i];
			sum+=BT[i];
		}
		int m=0;
		for(tim=0;tim<=sum;tim++)
	{
		int R=12;
		
		for(int k=0;k<n;k++)
			{
				if(op[k].AT<=tim && op[k].BT<R && op[k].BT>0 )
					{
						R=op[k].BT;
						index=k;
					}
			}
			op[index].BT-=1;
		
		if(op[index].BT==0)
		{
				end=tim+1;
				op[index].WT=end-op[index].AT-op[index].temp;
				op[index].Tat=end-op[index].AT;
				op[index].ct=op[index].Tat + op[index].AT;
				
				op[m].id=index;
				System.out.println("id"+ m + op[m].id + op[op[m].id].ct );
				m++;
		}
		

	}
		for(int i=0;i<n;i++)
	{
		Tat+=op[i].Tat;
		WT+=op[i].WT;
	}
		
		avg_tat=Tat/n;
		avg_wt=WT/n;
			/*System.out.print("     "+CT[i]+"\t\t\t");*/
			System.out.println("Turn Around Time = "+avg_tat);
			System.out.print("Waiting Time = "+avg_wt);
			
			System.out.println();
		return avg_wt;
	}
	
	
	
	public static void shuffleArray(int[] x2)
  	{
    	Random rnd = ThreadLocalRandom.current();
    	for (int i = x2.length - 1; i > 0; i--)
    	{
      		int index = rnd.nextInt(i + 1);
      		int a = x2[index];
      		x2[index] = x2[i];
      		x2[i] = a;
    	}
	}

		public float priority(int n2,int[] at2,int[] bt2)
		{
			int i,j,n,temp;
			n=n2;
			 at22=new int[n];
			int[] bt=new int[n];
			int[] pt=new int[n];
			int[] tat=new int[n];
			 ct22=new int[n];
			int[] wt=new int[n];
			int[] status=new int[n];
			 id22=new int[n];
			float avgwt=0; 
			for(i=0;i<n;i++)
			{
				at22[i]=at2[i];
				bt[i]=bt2[i];
				status[i]=0;
				ct22[i]=0;
				id22[i]=i;
				pt[i]=i+1;
			}

			shuffleArray(pt);
			System.out.println();
			int present_ind,p;int prev_ind=0;
			for(i=0;i<n;i++)
			{
				present_ind=findMin(pt,status,at22,ct22,prev_ind,n);
				System.out.println("i"+present_ind);
				status[present_ind]=1;
				if(ct22[prev_ind]>=at22[present_ind])
				{
					ct22[present_ind]=ct22[prev_ind]+bt[present_ind];
				}
				else
				{
					ct22[present_ind]=at22[present_ind]+bt[present_ind];
				}
				System.out.println("ct "+ct22[present_ind]);
				tat[present_ind]=ct22[present_ind]-at22[present_ind];
				wt[present_ind]=tat[present_ind]-bt[present_ind];
				avgwt=avgwt+wt[present_ind];
				prev_ind=present_ind;
		
			}
			
			for(i=0;i<n-1;i++)
			{
				for(j=i+1;j<n;j++)
				{
					if(ct22[i]>ct22[j])
					{
						temp=id22[i];
						id22[i]=id22[j];
						id22[j]=temp;
						
					}
				}
			}
			avgwt=avgwt/n;
			//System.out.println(avgwt);
			return avgwt;
		}		
	
}