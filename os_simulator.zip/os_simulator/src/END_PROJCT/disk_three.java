package END_PROJCT;



import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;




public class disk_three extends JFrame{
	/**
	 * 
	 */
	public JFrame frame=new JFrame();
	private static final long serialVersionUID = 1L;

	public disk_three() {
        super("XY Line Chart Example with JFreechart!!!");
 
        JPanel chartPanel = createChartPanel();
        chartPanel.setSize(100,100);
        //add(chartPanel, BorderLayout.CENTER);
 
        //frame.setSize(700,800);
        frame.add(chartPanel);
        frame.setBounds(100, 100, 700, 800);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        //frame.getContentPane().add(chartPanel);
        
    }
 
    public JPanel createChartPanel() {
        // creates a line chart object
        // returns the chart panel
    	String chartTitle = "Reader Writer Head Movement Chart";
        String xAxisLabel = "X";
       String yAxisLabel = "Y";
       
     //boolean plotOrientation;
        XYDataset dataset = createDataset();
     
        //Object plotOrientation;
		JFreeChart chart = ChartFactory.createXYLineChart(chartTitle,
                xAxisLabel, yAxisLabel, dataset);
		XYPlot plot=chart.getXYPlot();
		org.jfree.chart.axis.ValueAxis range = plot.getRangeAxis();
	       range.setVisible(false);
	       
		XYLineAndShapeRenderer render=new XYLineAndShapeRenderer();
		//render.getSeriesOutlinePaint(Color.RED);
		plot.setRenderer(render);
		
     
        return new ChartPanel(chart);
    	
    }
 
    private XYDataset createDataset() {
       
    	 XYSeriesCollection dataset = new XYSeriesCollection();
    	  
    	    XYSeries series3 = new XYSeries("Cylinders");
    	 
    	 int i;
    	   
    	    for(i=0;i<disk_first.n;i++)
    	    {
    	    	series3.add(disk_first.df[i],5*i);
    	    	
    	    }
    	    
    	    dataset.addSeries(series3);
    	 
    	    return dataset;

    }
 
    public  void req() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	try {
					disk_three window = new disk_three();
					window.frame.setVisible(true);
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
                
            }
        });
}
}