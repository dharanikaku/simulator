package END_PROJCT;
import java.io.*;
import java.lang.*;
import java.util.*;

public class page_main {
	public static String[][] bb1;
	public static String[][] bb2;
	public static String[][] bb3;
	public static String[][] bb4;
	
	public static int counti;
	public int fifo(int page[],int frame[],int pg,int fr)
	{
		bb1=new String[pg][fr];
		
		
		int n,t,m=0,x,i,l=0,s,k,req,j,cnt=0;
		n=fr;
		s=pg;
		for(j=0;j<n;j++)
		{
			frame[j]=-1;
		}
	
	
		     for(i=0;i<s;i++)
        	{
                req=0;
                for(k=0;k<n;k++)
                {
                        if(page[i]==frame[k])
                                req=1;
                }
                if (req==0)
                {
                        frame[l]=page[i];
                        l=(l+1)%n;
                        cnt++;
                }
                for(int g=0;g<n;g++)
                {
                	bb1[i][g]=String.valueOf(frame[g]);
                }

        	}
        System.out.println("Page Fault Is "+ cnt);
		
		return cnt;
	}
	public int lru(int page[],int frame[],int pg,int fr)
	{
		int[] A=new int[pg];
	int[] B=new int[fr];
	int[] Z=new int[fr];
	bb2=new String[pg][fr];
	int n,i,j;
	int first,count=0;
	int k=fr,flag,flag_queue,index=0,index_queue=0,range=0;
	Scanner S=new Scanner(System.in);
	n=pg;
	for(i=0;i<n;i++)
	{
		A[i]=page[i];
	}

	for(i=0;i<n;i++)
	{
		flag=0;flag_queue=0;
		if(i==0)
		{
			B[i]=A[i];
			Z[i]=A[i];
		}
		else
		{
			if(i>=k)
				range=k;
			else
				range=i;								
			for(j=0;j<range;j++)
			{
				if(A[i]==Z[j])
				{
					flag=1;
					break;
				}
			}
			if(flag==0&&range<k)
			{
				Z[i]=A[i];
				B[i]=A[i];
			}
			for(j=0;j<range;j++)
			{
				if(A[i]==B[j])
				{
					flag_queue=1;
					index_queue=j;
					break;
				}
			}
			if(flag==0&&range==k)
			{
				for(j=0;j<range;j++)
				{
					if(Z[j]==B[0])
					{
					index=j;
					break;
					}
				}
				Z[index]=A[i];
				for(j=0;j<range-1;j++)
				{
					B[j]=B[j+1];
				}
				B[range-1]=A[i];
			}
			if(flag_queue==1)
			{
				for(j=index_queue;j<range-1;j++)
				{
					B[j]=B[j+1];
				}
				B[range-1]=A[i];
			}
		}
			if (range==k)
				range=range-1;
			for(j=0;j<=range;j++)
			{
				System.out.print(j+":"+Z[j]+" ");
				bb2[i][j]=String.valueOf(Z[j]);
			}
			System.out.println();
			if(flag==0)
			{
				count=count+1;
				System.out.println("There is a page fault");
			}			
	}
	System.out.println("Total number of page faults are:"+count);
	counti=count;
	return count;
	}
	public int opt(int page[],int frame[],int pg,int fr)
	{
		int i,j,flag=0,n,fault=0,in=0,m=0,ff;
	Scanner sc=new Scanner(System.in);
	n=pg;
	
	ff=fr;
	//int frame[]=new int[ff];
	//int page[]=new int[n];
	int[] visited=new int[ff];
	int k[]=new int[ff];
	bb3=new String[n][ff];
	int[][] pt=new int[n][ff];
	int x;
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<ff;j++)
		{
			//bb[i][j]="a";
			pt[i][j]=0;
		}
	}
	
	//page_gui pp=new page_gui();
	//String row[] =new String[ff];
	for(i=0;i<ff;i++)
	{
		frame[i]=-1;
		k[i]=0;
	}
	for(i=0;i<n;i++)
	{
		//page[i]=sc.nextInt();
	}
	for(i=0;i<n;i++)
	{
		flag=0;
		int b=0;
		for(int p=0;p<ff;p++)
		{
			if(frame[p]!=-1)
			{
				b++;
			}
		}
		if(b==ff)
			break;
		else
		{
		for(j=0;j<ff;j++)
		{
			if(page[i]==frame[j])
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			frame[in]=page[i];
			fault++;
			in++;
		}
		}
		
		 //bb=new int[ff][pg];
		for(j=0;j<ff;j++)
		{
			System.out.print(frame[j]+" ");
				//row[j]=String.valueOf(frame[j]);
				bb3[i][j]=String.valueOf(frame[j]);
				pt[i][j]=frame[j];
				
		}
		//pp.model.addRow(row);
		
		System.out.println();				

	}
	for(;i<n;i++)
	{
		int c=0;
		for(j=0;j<ff;j++)
		{
			if(page[i]==frame[j])
			{
				c=1;
			}
		}
		if(c==0)
		{
			flag=0;
			int max=-1;
			function(page,frame,n,k,i+1,ff);
			for(x=0;x<ff;x++)
			{
				if(k[x]==0)
				{
					m=x;
					flag=1;
				}
			}
			if(flag==0)
			{
				for(int l=0;l<ff;l++)
				{
					if(max<k[l])
					{
						max=k[l];
						m=l;
					}
				}
			}
			frame[m]=page[i];
			fault++;
		}
		for(j=0;j<ff;j++)
		{
			System.out.print("^^ "+frame[j]+" ");
			bb3[i][j]=String.valueOf(frame[j]);
			pt[i][j]=frame[j];
		}
		System.out.println();	
	}		
		System.out.println("no of faults : "+ fault);
		int y,z;
		for(y=0;y<n;y++)
		{
			for(z=0;z<ff;z++)
			{
				//System.out.println("%%% "+i+" "+bb[y][z]);
				//System.out.println("%%% "+i+" "+pt[y][z]);
			}
		}
		counti=fault;
		//pp.scrollpane.setVisible(true);
		return fault;
	}
	public static void function(int[] page,int[] frame,int n,int[] k,int x,int ff)
{
	int[] visited=new int[ff];
	int i,j;
	for(i=0;i<ff;i++)
	{
		k[i]=0;
		visited[i]=0;
	}
	for(i=x;i<n;i++)
	{
		for(j=0;j<ff;j++)
		{
			if(frame[j]==page[i]&&visited[j]==0)
			{
				k[j]=i;
				 visited[j]=1;
			}
		
		}
	}
}
public int sca(int page[],int frame[],int pg,int fr)
{
	int n,ff;
	Scanner sc=new Scanner(System.in);
	n=pg;
	ff=fr;
	//Queue<Integer> queue=new LinkedList<Integer>();
	int i,j,flag;
	//int frame[]=new int[ff];
	//int page[]=new int[n];
	int ref[]=new int[ff];
	int counter[]=new int[ff];
	int index[]=new int[ff];
	int visited[]=new int[ff];
	int count=0;
	bb4=new String[n][ff];
	for(i=0;i<ff;i++)
	{
		frame[i]=-1;
		ref[i]=0;
		counter[i]=0;
	}
	for(i=0;i<n;i++)
	{
		//page[i]=sc.nextInt();
		//visited[i]=0;
	}
	int f=0;
	int k=0;
	int fault=0;
	i=0;
	int fi=0;
	for(i=0;i<n;)
	{
		flag=0;
		int b=0;
		for(int p=0;p<ff;p++)
		{
			if(frame[p]!=0)
			{
				b++;
			}
		}
		if(b==ff)
			break;
		for(j=0;j<ff;j++)
		{
			if(page[i]==frame[j])
			{
				flag=1;
				ref[j]=1;
				break;
			}
		}
		if (flag==0)
			{
				//System.out.println("f value... "+ fi);
				if(ref[fi]==0)
				{
				frame[fi]=page[i];
				System.out.println("initialFAULT"+page[i]);
				fault++;
				//queue.add(fi);
				count++;
				counter[fi]=count;
				fi++;
				//visited[i]=1;
				}
			}
		i++;
		for(int l=0;l<ff;l++)
		{
			System.out.print(frame[l]+"-"+ref[l]+" ");
			bb4[i][l]=String.valueOf(frame[l]);
		}
		//System.out.println("f value... "+ f);
	}
	for(;i<n;i++)
	{
		
		//System.out.println("f value.... "+f );
		flag=0;
		System.out.println("new coming: "+page[i]);
		for(j=0;j<ff;j++)
		{
			if(page[i]==frame[j])
			{
				flag=1;
				ref[j]=1;
				break;
			}
			
		}
		if(flag==0)
			{
				
				int q,w=0;
				for(q=0;q<ff;q++)
				{
					//counter[q]=0;
					visited[q]=0;
				}
				
				while(true)
				{
					int max=9999;
					//int ind=9999;
					for(f=0;f<ff;f++)
					{
						if(counter[f]<max&&visited[f]==0)
						{
							max=counter[f];
							w=f;
							//ind=index[f];
							//visited[f]=1;
						}
					}
					 if(ref[w]==0)
					{
						frame[w]=page[i];
						fault++;
						count++;
						counter[w]=count;
						break;
					}
					else if(ref[w]==1)
					{
						ref[w]=0;
						visited[w]=1;
						//counter[w]++;
					}
					
				}
				
			}					
		for(j=0;j<ff;j++)
		{
			System.out.print(frame[j]+"-"+ref[j]+" ");
			bb4[i][j]=String.valueOf(frame[j]);
		}
	
	//System.out.println("no of faults : "+fault);
}
	System.out.println("no of faults : "+fault);
	counti=fault;
	return fault;
}
public  void input()

{
	page_main p=new page_main();
	Random r=new Random();
	Scanner sc=new Scanner(System.in);
	int n=r.nextInt(20)+1;
	int m=r.nextInt(5)+1;
	int i,j;
	int a[]=new int[n];
	int b[]=new int[m];
	int a1[]=new int[n];
	int a2[]=new int[n];
	int a3[]=new int[n];
	int a4[]=new int[n];
	int b1[]=new int[m];
	int b2[]=new int[m];
	int b3[]=new int[m];
	int b4[]=new int[m];
	for(i=0;i<n;i++)
	{
		a[i]=r.nextInt(10)+1;
		a1[i]=a[i];
		a2[i]=a[i];
		a3[i]=a[i];
		a4[i]=a[i];	
	}
	for(j=0;j<m;j++)
	{
		b[j]=0;
		b1[j]=0;
		b2[j]=0;
		b3[j]=0;
		b4[j]=0;
	}
	int fi=p.fifo(a1,b1,n,m);
	int lr=p.lru(a2,b2,n,m);
	int op=p.opt(a3,b3,n,m);
	int sec=p.sca(a4,b4,n,m);	
}
}

