package END_PROJCT;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import java.awt.Color;


import javax.swing.JButton;
import javax.swing.JScrollPane;

public class disk_sec implements ActionListener {

	public JFrame frame;
	public int f;
	public int array[];
	public JTextArea inp_array = new JTextArea();
	public JTextField txtHiran=new JTextField(); 
	public JScrollPane jp;
	public JTextArea output = new JTextArea();
	public JScrollPane oup1=new JScrollPane();
	public JScrollPane oup2=new JScrollPane();
	public JScrollPane oup3=new JScrollPane();
	public JScrollPane oup4=new JScrollPane();
	public JScrollPane oup5=new JScrollPane();
	public JScrollPane oup6=new JScrollPane();
	JButton bgrp = new JButton("graphs");
	public static int c1,c2,c3,c4,c5,c6;
	/**
	 * Launch the application.
	 */
	
	/*public static void main(String[]args)
	{
		Test d=new Test();
	}*/
	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public disk_sec() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		JLabel lblNoOfMoves = new JLabel("no of moves");
		lblNoOfMoves.setBounds(31, 243, 121, 15);
		frame.getContentPane().add(lblNoOfMoves);
		//JTextField txtHiran=new JTextField();
		txtHiran.setForeground(Color.BLACK);
		txtHiran.setBackground(Color.WHITE);
		txtHiran.setBounds(133, 241, 114, 19);
		frame.getContentPane().add(txtHiran);
		txtHiran.setColumns(10);
		
		//JTextArea inp_array = new JTextArea();
		
		inp_array.setBounds(132, 12, 264, 75);
		//jp.setBounds(179, 172, 259, 77);
	     
		output.setBounds(122, 116, 259, 77);
		frame.getContentPane().add(output);
		frame.getContentPane().add(oup1);
		frame.getContentPane().add(oup2);
		frame.getContentPane().add(oup3);
		frame.getContentPane().add(oup4);
		frame.getContentPane().add(oup5);
		frame.getContentPane().add(oup6);
		
		JLabel lblOutput = new JLabel("output");
		lblOutput.setBounds(22, 146, 70, 15);
		frame.getContentPane().add(lblOutput);
		
		JLabel lblInput = new JLabel("input");
		lblInput.setBounds(22, 50, 70, 15);
		frame.getContentPane().add(lblInput);
		
		
		bgrp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				disk_three d3=new disk_three();
				d3.createChartPanel();
				d3.req();
				
				
				
			//d3.req();
			//d3.frame.setVisible(true);
			}
		});		
		bgrp.setBounds(61, 316, 121, 32);
		frame.getContentPane().add(bgrp);
		
		JButton btnPieChart = new JButton("pie chart");
		btnPieChart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				disk_four e1=new disk_four();
				disk_main dm=new disk_main();
				//System.out.println("inininin");
				c1=dm.dfcfs(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				c2=dm.dsstf(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				c3=dm.dscan(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				c4=dm.dcscan(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				c5=dm.look(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				c6=dm.clook(disk_first.df,disk_first.n,disk_first.hpointer,disk_first.min,disk_first.max);
				//System.out.println("^^^ "+c1+" "+" "+c2+" "+c3+" "+c4+" "+c5+" "+c6);
				e1.createChart();
				e1.req();
				
				
			}
		});
		btnPieChart.setBounds(284, 313, 117, 32);
		frame.getContentPane().add(btnPieChart);
		
		
		
		//frame.getContentPane().add(jp);
		
		//JScrollPane scrollPane = new JScrollPane(inp_array);
		//JScrollPane areaScrollPane = new JScrollPane(inp_array);
		//areaScrollPane.setVerticalScrollBarPolicy(
		                //JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		//areaScrollPane.setPreferredSize(new Dimension(250, 250));
		//frame.getContentPane().add(areaScrollPane);
		//JTextField txtHiran = new JTextField();
		
		
		
		
		
	}
	
	public  void hiran(int k,int[] a1,int n) {
		
		//Test t=new Test();
		//t.f=k;
		
		/*for(i=0;i<n;i++)
		{
			//t.array[i]=a1[i];
			//t.inp_array.append(String.valueOf(a1[i]+" "));
			//t.txtHiran.setText(String.valueOf(f));
		}*/
		//System.out.println("entered");
		
		
		//txtHiran.setText(String.valueOf("hello"));
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					disk_sec  window = new disk_sec();
					window.frame.setVisible(true);
					
					
					
					
					txtHiran.setText("hello");
					txtHiran.setEditable(false);
					txtHiran.setVisible(true);
					System.out.println("hiran");
					//txtHiran.setText(k);
				} catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}