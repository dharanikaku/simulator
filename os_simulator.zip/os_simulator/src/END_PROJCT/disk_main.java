package END_PROJCT;
import java.util.*;
public class disk_main {
	
	protected Object dscan;
	public int[] seq;
	List<Integer> b1=new ArrayList<Integer>();
	List<Integer> b2=new ArrayList<Integer>();
	List<Integer> a1=new ArrayList<Integer>();
	List<Integer> n1=new ArrayList<Integer>();
	public int dfcfs(int a1[],int n,int head,int cmin,int cmax)
	{
		int t;
		Scanner S=new Scanner(System.in);
		//n=S.nextInt();
		int[] A=new int[n];
		seq=new int[n];
		int sum=0,init;
		int i;
		for(i=0;i<n;i++)
		{
			A[i]=a1[i];
			seq[i]=a1[i];
			
		}
		init=head;
		sum=sum+(init-A[0]);
		if(sum<0)
			sum=sum*-1;
		for(i=0;i<=n-2;i++)
		{
			t=A[i+1]-A[i];
			if(t<0)
				t=t*-1;
			sum=sum+t;
		}

		System.out.println("Total number of cylinders "+sum);
		return sum;
	}
	
	public static int getmin(int x,int[] u,int r,boolean[] v)
	{
		int i,min,t,temp;
		int index=0;
		min=100000;
		for(i=0;i<r;i++)
		{
			if(u[i]==x)
				continue;
			if(v[i]==false)
			{
				t=u[i]-x;
				if(t<0)
					t=t*-1;
				if(t<min)
				{
					min=t;
					index=i;
				}
			}
		}
		return index;		
	}	
	
	public int dsstf(int a2[],int n,int head,int cmin,int cmax)
	{
		int i,init,min,max,sum=0,q,t,tb,count,ind;
		Scanner S=new Scanner(System.in);
		//n=S.nextInt();
		int[] A=new int[n];
		seq=new int[n];
		boolean[] visit=new boolean[n];
		for(i=0;i<n;i++)
		{
			A[i]=a2[i];
			visit[i]=false;
		}
		init=head;
		count=n-1;
		t=getmin(init,A,n,visit);
		sum=sum+(A[t]-init);
		i=0;
		while(count>0)
		{
			tb=t;
			visit[tb]=true;
			seq[i]=A[tb];
			t=getmin(A[tb],A,n,visit);
			q=A[t]-A[tb];
			if(q<0)
				q=q*-1;
			sum=sum+q;
			i=i+1;
			count=count-1;			
		}
		seq[n-1]=A[t];
		for(i=0;i<=n-1;i++)
		{
			System.out.print(seq[i]+" ");
						
		}
		System.out.println();
		System.out.println("Total number cylinders "+sum);
		return sum;
	}
	public int dscan(int a3[],int n,int head,int cmin,int cmax)
	{
		int i,init,start,end,count1=0,count2=0,way,sum=0,p,q;
		Scanner S=new Scanner(System.in);
		//n=S.nextInt();
		start=cmin;
		end=cmax;
		int[] A=new int[n];
		for(i=0;i<n;i++)
		{
			A[i]=a3[i];
		}
		init=head;
		for(i=0;i<n;i++)
		{
			if(A[i]<init)
				count1=count1+1;
			else
				count2=count2+1;

		}
		if(count1>=count2)
			way=1;
		else
			way=2;
		int[] subl=new int[count1];
		int[] subr=new int[count2];
		seq=new int[n];
		p=0;q=0;
		for(i=0;i<n;i++)
		{
			if(A[i]<init)
			{
				subl[p]=A[i];p++;
			}
			else
			{
				subr[q]=A[i];q++;

			}
		}
		
		Arrays.sort(subl);
		Arrays.sort(subr);
		//System.out.print(init+" ");
		if(way==2)
		{
			sum=sum+(init-start);
			sum=sum+(subr[count2-1]-start);
			for(i=count1-1;i>=0;i--)
			{
				b1.add(subl[i]);
			}
		b1.add(start);
			for(i=0;i<count2;i++)
			{
				b1.add(subr[i]);

			}			
		}
		if(way==1)
		{
			sum=sum+(end-init);
			sum=sum+(end-subl[0]);
			for(i=0;i<count2;i++)
			{
				b1.add(subr[i]);
			}
			b1.add(end);
			for(i=count1-1;i>=0;i--)
			{
				b1.add(subl[i]);
			}	
		}
		for(i=0;i<n+1;i++)
		{
			System.out.print(b1.get(i)+" ");
		}
		

		System.out.println();
		System.out.println("total cylinders movement "+sum);
		return sum;
	}
	public int dcscan(int a4[],int n,int head,int cmin,int cmax)
	{
		int i,init,start,end,count1=0,count2=0,way,sum=0,p,q;
		Scanner S=new Scanner(System.in);
		//n=S.nextInt();
		start=cmin;
		end=cmax;
		int[] A=new int[n];
		for(i=0;i<n;i++)
		{
			A[i]=a4[i];
		}
		init=head;
		for(i=0;i<n;i++)
		{
			if(A[i]<init)
				count1=count1+1;
			else
				count2=count2+1;

		}
		if(count1>=count2)
			way=1;
		else
			way=2;
		int[] subl=new int[count1];
		int[] subr=new int[count2];
		seq=new int[n];
		p=0;q=0;
		for(i=0;i<n;i++)
		{
			if(A[i]<init)
			{
				subl[p]=A[i];p++;
			}
			else
			{
				subr[q]=A[i];q++;

			}
		}
		int z=0;
		Arrays.sort(subl);
		Arrays.sort(subr);
		b2.add(init);
		if(way==1)
		{
			sum=sum+(init-start);
			sum=sum+(end-subr[0]);
			for(i=count1-1;i>=0;i--)
			{
				
				b2.add(subl[i]);
			}
			b2.add(start);
			b2.add(end);
			for(i=count2-1;i>=0;i--)
			{
				b2.add(subr[i]);

			}			
		}
		if(way==2)
		{
			sum=sum+(end-init);
			sum=sum+(subl[count1-1]-start);
			for(i=0;i<count2;i++)
			{
				b2.add(subr[i]);
			}
			b2.add(end);
			b2.add(start);
			for(i=0;i<count1;i++)
			{
				b2.add(subl[i]);
			}	
		}
		System.out.println();
		for(i=0;i<n+3;i++)
		{
			System.out.print(b2.get(i)+" ");
		}
		System.out.println("total cylinders movement "+sum);
		return sum;
	}
	public int look(int a5[],int n,int head,int cmin,int cmax)
	{
		int min,max,i,j,pointer=0,moves=0,header,temp;
		Scanner sc=new Scanner(System.in);
		//n=sc.nextInt();
		//min=sc.nextInt();
		//max=sc.nextInt();
		//head=sc.nextInt();
		header=head;
		int interval[]=new int[n];
		int visited[]=new int[n];
		for(i=0;i<n;i++)
		{
			interval[i]=a5[i];
			visited[i]=0;
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				if(interval[i]<interval[j])
				{
					temp=interval[i];
					interval[i]=interval[j];
					interval[j]=temp;
				}
			}
		}
		/*for(int k=0;k<n;k++)
		{
			System.out.println(interval[k]);
		}*/
		for(j=0;j<n;j++)
		{
			if(interval[j]>head)
			{
				System.out.println(interval[j]+" "+head);
				pointer=j-1;
				break;
			}
		}
		System.out.println(pointer);
		for(i=pointer;i>=0;i--)
		{
			moves=moves+(head-interval[i]);
			head=interval[i];
			n1.add(interval[i]);
		}
		//System.out.println(moves);
		//moves=moves+(header-interval[0]);
		//head=interval[pointer+1];
		//System.out.println(moves);
		for(i=pointer+1;i<n;i++)
		{
			moves=moves+(interval[i]-head);
			n1.add(interval[i]);
			head=interval[i];
		}
		System.out.println("no of moves : "+ moves);
		return moves;
	}
	public int clook(int a6[],int n,int head,int cmin, int cmax)
	{
	int h;int index=0;int count=0;int cc,co;int x=0;
		  
		 
		  h=head;
		  int[] k=new int[n];
		  for(int i=0;i<n;i++)
		   {
		     k[i]=a6[i];
		   }
		 Arrays.sort(k);
		 
		//for(int i=0;i<n;i++)
		//{
		 //System.out.println(k[i]);
		//}
		   for(int i=0;i<n;i++)
		   {
		    if(k[i]>h)
		     {
		      index=i;
			break;
		     }
		   else
		{
		  index=n;
		}
		   }
		//System.out.println(index);
		  a1.add(h);
		  cc=f(k,index,count,h,cmax,n,a1);
		  int j=index-1;
		   co=ff(k,j,x,h,cmax,a1);
		 int finalcount=cc+co;
		 System.out.println(finalcount);
		for(int i=0;i<=n;i++)
		{
		System.out.println(a1.get(i));
		}
		return finalcount;
	}
	public static int f(int[] k,int index,int count,int h,int cmax,int n,List<Integer> a1)
	 {int x;
	  if(index==n-1)
	  {
	   count=count+k[index]-h;
	   a1.add(k[index]);

	}
	else
	{
	  count=k[index]-h;
	  for(int i=index;i<n-1;i++)
	  { 
	   a1.add(k[i]);
	   x=k[i+1]-k[i];
	   count=count+x;
	  }
	a1.add(k[n-1]);
	System.out.println(count);
	}
	 return count;
	 }
	 public static int ff(int[] k,int j,int x,int h,int cmax,List<Integer> a1)
	 {
	  int c;
	if(j==0)
	{
	c=0;
	a1.add(k[j]);

	}
	// System.out.println(j);
	else if (j==1)
	{
	 c=k[1]-k[0];
	a1.add(k[0]);
	a1.add(k[1]);
	x=x+c;
	}
	else{
	  for(int i=0;i<=j;i++)
	  {
	   c=k[i+1]-k[i];
	    a1.add(k[i]);
	   x=x+c; 
	  }
	 // a1.add(k[j]);
	}
	System.out.println(x);
	return x;
	}  
	public static void main(String[] args)
	{
		disk_main d=new disk_main();
		int n,i,cmin,cmax,head;
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		cmin=sc.nextInt();
		cmax=sc.nextInt();
		head=sc.nextInt();
		int moves[]=new int[n];
		int a1[]=new int[n];
		int a2[]=new int[n];
		int a3[]=new int[n];
		int a4[]=new int[n];
		int a5[]=new int[n];
		int a6[]=new int[n];
		for(i=0;i<n;i++)
		{
			moves[i]=sc.nextInt();
		}
		int k1=d.dfcfs(a1,n,head,cmin,cmax);
		int k2=d.dsstf(a2,n,head,cmin,cmax);
		int k3=d.dscan(a3,n,head,cmin,cmax);
		int k4=d.dcscan(a4,n,head,cmin,cmax);
		int k5=d.look(a5,n,head,cmin,cmax);
		int k6=d.clook(a6,n,head,cmin,cmax);			
	}

	

}