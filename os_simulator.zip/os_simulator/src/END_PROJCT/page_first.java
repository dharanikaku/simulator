package END_PROJCT;

import java.awt.EventQueue;
import java.awt.event.*;
import javax.swing.*;

import java.util.*;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.GroupLayout.Alignment;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.SystemColor;
public class page_first extends page_main{

	private JFrame frame;
	private JTextField fifo_res;
	private JTextField lru_res;
	private JTextField opt_res;
	private JTextField sec_res;
	private JButton btnBest;
	private JTextField best_res;
	public static int fi,lr,op,sec,m,n;
	public String ss[];
	public String obj[][];
	public int a[];
	public int total_count1,total_count2,total_count3,total_count4;
	//public DefaultTableModel model=new DefaultTableModel();
	public JTable table;
	private JTextField framesize;
 	/**
	 * Launch the application.
	 */
	public void req() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					page_first window = new page_first();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public page_first() {
		initialize();
	}

	 void confirmAndExit() {
		    if (JOptionPane.showConfirmDialog(
		      frame,
		      "Are you sure you want to quit?",
		      "Please confirm",
		      JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION
		    ) {
		    	frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		    	
		    }
		  }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		

		frame = new JFrame();
		
		
		JMenuBar bar=new JMenuBar();
		JMenu file,process,dinning,page,disk,help;
		JMenuItem exiti,homei,processi,dinningi,pagei,diski,helpi;
		
		file=new JMenu("File");
		process=new JMenu("Process");
		dinning=new JMenu("Dinning");
		page=new JMenu("Page");
		disk=new JMenu("Disk");
		help=new JMenu("Help");
		bar.add(file);
		bar.add(process);
		bar.add(dinning);
		bar.add(page);
		bar.add(disk);
		bar.add(help);
		ImageIcon si11=new ImageIcon("/home/indian/Documents/exit.png");
		ImageIcon si12=new ImageIcon("/home/indian/Documents/blue-home-icon.png");
		ImageIcon si4=new ImageIcon("/home/indian/Documents/disk1.png");
		exiti=new JMenuItem("Exit",si11);
		
		homei=new JMenuItem("Home",si12);
		homei.setMnemonic(KeyEvent.VK_H);
		processi=new JMenuItem("CPU Scheduling");
		dinningi=new JMenuItem("Dinning Philosophers");
		pagei=new JMenuItem("Page Replacement");
		diski=new JMenuItem("Disk Management",si4);
		helpi=new JMenuItem("Help");
		file.add(exiti);
		file.add(homei);
		process.add(processi);
		dinning.add(dinningi);
		page.add(pagei);
		disk.add(diski);
		diski.setMnemonic(KeyEvent.VK_D);
		help.add(helpi);
		frame.setJMenuBar(bar);
		
		
		exiti.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				confirmAndExit();
			}
		});

diski.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				disk_first ds1=new disk_first();
				ds1.req();
			}
		});
processi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		a_start a1=new a_start();
		a1.req();
	}
});
dinningi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		edited z=new edited();
		z.req();
	}
});
pagei.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		//page_first pf=new page_first();
		//pf.req();
	}
});
	
		
		frame.setBackground(new Color(255, 255, 255));
		frame.getContentPane().setBackground(new Color(153, 204, 255));
		frame.getContentPane().setForeground(Color.LIGHT_GRAY);
		frame.setBounds(100, 100, 489, 517);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.addWindowListener(new WindowAdapter() {
		      @Override
		      public void windowClosing(WindowEvent event) {
		        confirmAndExit();
		      }
		    });
		
		JButton gen_input = new JButton("generate input");
		gen_input.setBackground(new Color(153, 204, 204));
		gen_input.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				page_sec z=new page_sec();
				page_main p=new page_main();
				Random r=new Random();
				Scanner sc=new Scanner(System.in);
				 n=r.nextInt(20)+1;
				 m=Integer.parseInt(framesize.getText());
				int i,j;
			    a=new int[n];
				int b[]=new int[m];
				int a1[]=new int[n];
				int a2[]=new int[n];
				int a3[]=new int[n];
				int a4[]=new int[n];
				int b1[]=new int[m];
				int b2[]=new int[m];
				int b3[]=new int[m];
				int b4[]=new int[m];
				for(i=0;i<n;i++)
				{
					a[i]=r.nextInt(10)+1;
					//z.textArea.append(String.valueOf(a[i])+" ");
					a1[i]=a[i];
					a2[i]=a[i];
					a3[i]=a[i];
					a4[i]=a[i];	
				}
				for(j=0;j<m;j++)
				{
					b[j]=0;
					b1[j]=0;
					b2[j]=0;
					b3[j]=0;
					b4[j]=0;
				}
				int g;
				for(g=0;g<n;g++)
				{
				System.out.print(a[g]+" ");		
				}
				System.out.println();
				 fi=p.fifo(a1,b1,n,m);
				 //total_count1=fi;
				 lr=p.lru(a2,b2,n,m);
				 total_count2=lr;
				 op=p.opt(a3,b3,n,m);
				 total_count3=lr;
				 sec=p.sca(a4,b4,n,m);
				 total_count4=sec;
				 fifo_res.setText(String.valueOf(""));
				 lru_res.setText(String.valueOf(""));
				 opt_res.setText(String.valueOf(""));
				 sec_res.setText(String.valueOf(""));
				 System.out.println("$$$$ "+ counti);
				 opt_res.setText(String.valueOf(op));
				 lru_res.setText(String.valueOf(lr));
				 sec_res.setText(String.valueOf(sec));
				 fifo_res.setText(String.valueOf(fi));

			}
		});
		gen_input.setBounds(173, 125, 166, 34);
		frame.getContentPane().add(gen_input);
		
		fifo_res = new JTextField();
		fifo_res.setBounds(74, 238, 124, 25);
		frame.getContentPane().add(fifo_res);
		fifo_res.setColumns(10);
		fifo_res.setEditable(false);
		
		lru_res = new JTextField();
		lru_res.setBounds(274, 238, 122, 25);
		frame.getContentPane().add(lru_res);
		lru_res.setColumns(10);
		lru_res.setEditable(false);
		
		JButton btnLru = new JButton("lru");
		btnLru.setForeground(new Color(255, 255, 255));
		btnLru.setBackground(new Color(51, 0, 153));
		btnLru.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//page_gui2 y=new page_gui2();
				//y.gui2();
				
				page_main pr=new page_main();
				page_sec y=new page_sec();
				//y.gui2();
				String ss[]= new String[m];
				int i,j;
				for(i=0;i<m;i++)
				{
					ss[i]=String.valueOf(i);
				}
				String obj[][]=new String[20][20];
				
				
				y.textArea = new JTextArea();
				y.textArea.setBounds(145, 12, 279, 51);
				y.frame.getContentPane().add(y.textArea);
				
				for(i=0;i<n;i++)
				{
					y.textArea.append(String.valueOf(a[i]+" "));
				}
				y.textArea.setEditable(false);
				
				y.count = new JTextField();
				y.count.setBounds(220, 91, 114, 19);
				y.frame.getContentPane().add(y.count);
				y.count.setColumns(10);
				
				y.count.setText(String.valueOf(lr));
				y.count.setEditable(false);
				
				int u,z;
				for(u=0;u<n;u++)
				{
					for(z=0;z<m;z++)
					{
						System.out.println("&&&&&");
						//System.out.println("********* "+u+" "+pr.bb[u][z]);
						//System.out.println("%%% "+i+" "+pt[y][z]);
					}
				}
				y.frtable = new JTable(pr.bb2,ss);
				y.scrollpane1=new JScrollPane(y.frtable);

				y.scrollpane1.setBounds(86, 195, 414, 172);
				y.frame.getContentPane().add(y.scrollpane1);
				y.scrollpane1.setVisible(true);
				y.frame.setVisible(true);
				
				lru_res.setText(String.valueOf(lr));
			}
		});
		btnLru.setBounds(279, 181, 117, 25);
		frame.getContentPane().add(btnLru);
		
		JButton btnFifo = new JButton("fifo");
		btnFifo.setForeground(new Color(255, 255, 255));
		btnFifo.setBackground(new Color(51, 0, 153));
		btnFifo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				page_main pr=new page_main();
				page_sec y=new page_sec();
				//y.gui2();
				String ss[]= new String[m];
				int i,j;
				for(i=0;i<m;i++)
				{
					ss[i]=String.valueOf(i);
				}
				String obj[][]=new String[20][20];
				
				
				y.textArea = new JTextArea();
				y.textArea.setBounds(145, 12, 279, 51);
				y.frame.getContentPane().add(y.textArea);
				
				for(i=0;i<n;i++)
				{
					y.textArea.append(String.valueOf(a[i]+" "));
				}
				y.textArea.setEditable(false);
				
				y.count = new JTextField();
				y.count.setBounds(220, 91, 114, 19);
				y.frame.getContentPane().add(y.count);
				y.count.setColumns(10);
				
				y.count.setText(String.valueOf(fi));
				y.count.setEditable(false);
				
				int u,z;
				for(u=0;u<n;u++)
				{
					for(z=0;z<m;z++)
					{
						System.out.println("&&&&&");
						//System.out.println("********* "+u+" "+pr.bb[u][z]);
						//System.out.println("%%% "+i+" "+pt[y][z]);
					}
				}
				y.frtable = new JTable(pr.bb1,ss);
				y.scrollpane1=new JScrollPane(y.frtable);

				y.scrollpane1.setBounds(86, 195, 414, 172);
				y.frame.getContentPane().add(y.scrollpane1);
				y.scrollpane1.setVisible(true);
				y.frame.setVisible(true);
				y.count.setText(String.valueOf(counti));
				//opt_res.setText(String.valueOf(op));
			}
		});
		btnFifo.setBounds(81, 181, 117, 25);
		frame.getContentPane().add(btnFifo);
		
		JButton btnOptimal = new JButton("optimal");
		btnOptimal.setForeground(new Color(255, 255, 255));
		btnOptimal.setBackground(new Color(51, 0, 153));
		btnOptimal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				page_main pr=new page_main();
				page_sec y=new page_sec();
				//y.gui2();
				String ss[]= new String[m];
				int i,j;
				for(i=0;i<m;i++)
				{
					ss[i]=String.valueOf(i);
				}
				String obj[][]=new String[20][20];
				
				
				y.textArea = new JTextArea();
				y.textArea.setBounds(145, 12, 279, 51);
				y.frame.getContentPane().add(y.textArea);
				
				for(i=0;i<n;i++)
				{
					y.textArea.append(String.valueOf(a[i]+" "));
				}
				y.textArea.setEditable(false);
				
				y.count = new JTextField();
				y.count.setBounds(220, 91, 114, 19);
				y.frame.getContentPane().add(y.count);
				y.count.setColumns(10);
				
				y.count.setText(String.valueOf(op));
				y.count.setEditable(false);
				
				int u,z;
				for(u=0;u<n;u++)
				{
					for(z=0;z<m;z++)
					{
						System.out.println("&&&&&");
						//System.out.println("********* "+u+" "+pr.bb[u][z]);
						//System.out.println("%%% "+i+" "+pt[y][z]);
					}
				}
				y.frtable = new JTable(pr.bb3,ss);
				y.scrollpane1=new JScrollPane(y.frtable);

				y.scrollpane1.setBounds(86, 195, 414, 172);
				y.frame.getContentPane().add(y.scrollpane1);
				y.scrollpane1.setVisible(true);
				y.frame.setVisible(true);
				opt_res.setText(String.valueOf(op));
			}
		});
		btnOptimal.setBounds(74, 300, 124, 25);
		frame.getContentPane().add(btnOptimal);
		
		JButton btnSecchance = new JButton("sec_chance");
		btnSecchance.setForeground(new Color(255, 255, 255));
		btnSecchance.setBackground(new Color(51, 0, 153));
		btnSecchance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				page_main pr=new page_main();
				page_sec y=new page_sec();
				//y.gui2();
				String ss[]= new String[m];
				int i,j;
				for(i=0;i<m;i++)
				{
					ss[i]=String.valueOf(i);
				}
				String obj[][]=new String[20][20];
				
				
				y.textArea = new JTextArea();
				y.textArea.setBounds(145, 12, 279, 51);
				y.frame.getContentPane().add(y.textArea);
				
				y.count = new JTextField();
				y.count.setBounds(220, 91, 114, 19);
				y.frame.getContentPane().add(y.count);
				y.count.setColumns(10);
				
				y.count.setText(String.valueOf(sec));
				y.count.setEditable(false);
				for(i=0;i<n;i++)
				{
					y.textArea.append(String.valueOf(a[i]+" "));
				}
				y.textArea.setEditable(false);
				int u,z;
				for(u=0;u<n;u++)
				{
					for(z=0;z<m;z++)
					{
						System.out.println("&&&&&");
						//System.out.println("********* "+u+" "+pr.bb[u][z]);
						//System.out.println("%%% "+i+" "+pt[y][z]);
					}
				}
				y.frtable = new JTable(pr.bb4,ss);
				y.scrollpane1=new JScrollPane(y.frtable);

				y.scrollpane1.setBounds(86, 195, 414, 172);
				y.frame.getContentPane().add(y.scrollpane1);
				y.scrollpane1.setVisible(true);
				y.frame.setVisible(true);
				//y.frtable.setEditable(false);
				
				sec_res.setText(String.valueOf(sec));
			}
		});
		btnSecchance.setBounds(283, 300, 124, 25);
		frame.getContentPane().add(btnSecchance);
		
		opt_res = new JTextField();
		opt_res.setBounds(74, 354, 124, 25);
		frame.getContentPane().add(opt_res);
		opt_res.setColumns(10);
		opt_res.setEditable(false);
		
		sec_res = new JTextField();
		sec_res.setBounds(285, 351, 122, 28);
		frame.getContentPane().add(sec_res);
		sec_res.setColumns(10);
		sec_res.setEditable(false);
		
		ss= new String[m];
		int i,j;
		for(i=0;i<m;i++)
		{
			ss[i]=String.valueOf(i);
		}
		obj=new String[20][20];
		for(i=0;i<20;i++)
		{
			for(j=0;j<3;j++)
			{
				obj[i][j]="god";
			}
		}
		 /**/
		
		JLabel lblNoOfFrames = new JLabel("no of frames");
		lblNoOfFrames.setBounds(26, 72, 97, 15);
		frame.getContentPane().add(lblNoOfFrames);
		
		framesize = new JTextField();
		framesize.setBackground(new Color(204, 204, 204));
		framesize.setBounds(173, 70, 97, 19);
		frame.getContentPane().add(framesize);
		framesize.setColumns(10);
		
		JButton btnCompare = new JButton("compare");
		btnCompare.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				page_three t3=new page_three();
				t3.createChart();
				t3.req();
				
			}
		});
		btnCompare.setBounds(180, 448, 117, 25);
		frame.getContentPane().add(btnCompare);
		
		
		/*btnBest = new JButton("best");
		btnBest.setBounds(172, 270, 117, 25);
		frame.getContentPane().add(btnBest);
		
		best_res = new JTextField();
		best_res.setBounds(172, 307, 122, 25);
		frame.getContentPane().add(best_res);
		best_res.setColumns(10);*/
	}
}