package END_PROJCT;

import java.awt.EventQueue;
import java.awt.event.*;
import javax.swing.*;

import org.jfree.data.xy.XYDataItem;

import java.util.Enumeration;
import java.util.*;
import java.awt.Color;
public class disk_first {

	private JFrame frame;
	private JTextField no_of_sec;
	private JTextField lbound;
	private JTextField ubound;
	private JTextField head;
	public static int[] df;
	public static int n,hpointer,min,max;
	public int k=0;
	/**
	 * Launch the application.
	 */
	public void req() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					disk_first window = new disk_first();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public disk_first (){
		initialize();
	}

	public String unibutton(ButtonGroup grp)
	{
		for(Enumeration<AbstractButton> buttons=grp.getElements();buttons.hasMoreElements();)
		{
			AbstractButton  button = buttons.nextElement();
			if(button.isSelected())
			{
				return button.getText();
			
			}
		}
		return null;
	}
	public boolean not_avail(int[] x,int len,int num)
	{ int i,count=0;
		for(i=0;i<len;i++)
		{
			if(num!=x[i])
			{
				count=count+1;
			}			
		}
		if(count==len)
			return true;
		else
			return false;
	}
	
	 void confirmAndExit() {
		    if (JOptionPane.showConfirmDialog(
		      frame,
		      "Are you sure you want to quit?",
		      "Please confirm",
		      JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION
		    ) {
		    	frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		    }
		  }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		
		
		
		JMenuBar bar=new JMenuBar();
		JMenu file,process,dinning,page,disk,help;
		JMenuItem exiti,homei,processi,dinningi,pagei,diski,helpi;
		
		file=new JMenu("File");
		process=new JMenu("Process");
		dinning=new JMenu("Dinning");
		page=new JMenu("Page");
		disk=new JMenu("Disk");
		help=new JMenu("Help");
		bar.add(file);
		bar.add(process);
		bar.add(dinning);
		bar.add(page);
		bar.add(disk);
		bar.add(help);
		ImageIcon si11=new ImageIcon("/home/indian/Documents/exit.png");
		ImageIcon si12=new ImageIcon("/home/indian/Documents/blue-home-icon.png");
		ImageIcon si4=new ImageIcon("/home/indian/Documents/disk1.png");
		exiti=new JMenuItem("Exit",si11);
		
		homei=new JMenuItem("Home",si12);
		homei.setMnemonic(KeyEvent.VK_H);
		processi=new JMenuItem("CPU Scheduling");
		dinningi=new JMenuItem("Dinning Philosophers");
		pagei=new JMenuItem("Page Replacement");
		diski=new JMenuItem("Disk Management",si4);
		helpi=new JMenuItem("Help");
		file.add(exiti);
		file.add(homei);
		process.add(processi);
		dinning.add(dinningi);
		page.add(pagei);
		disk.add(diski);
		diski.setMnemonic(KeyEvent.VK_D);
		help.add(helpi);
		frame.setJMenuBar(bar);
		
		
		exiti.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				confirmAndExit();
			}
		});

diski.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				//disk_first ds1=new disk_first();
				//ds1.req();
			}
		});
processi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		a_start a1=new a_start();
		a1.req();
	}
});
dinningi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		edited z=new edited();
		z.req();
	}
});
pagei.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		page_first pf=new page_first();
		pf.req();
	}
});
		
		
		
		
		
		
		frame.setBackground(new Color(0, 102, 153));
		frame.getContentPane().setBackground(new Color(102, 204, 255));
		frame.setBounds(100, 100, 450, 433);
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.addWindowListener(new WindowAdapter() {
		      @Override
		      public void windowClosing(WindowEvent event) {
		        confirmAndExit();
		      }
		    });
		
		no_of_sec = new JTextField();
		no_of_sec.setBackground(new Color(255, 255, 204));
		no_of_sec.setBounds(220, 76, 114, 19);
		frame.getContentPane().add(no_of_sec);
		no_of_sec.setColumns(10);
		
		JLabel lblNoOfSectors = new JLabel("no of sectors");
		lblNoOfSectors.setBounds(67, 78, 114, 15);
		frame.getContentPane().add(lblNoOfSectors);
		
		lbound = new JTextField();
		lbound.setBackground(new Color(255, 255, 204));
		lbound.setBounds(220, 123, 114, 19);
		frame.getContentPane().add(lbound);
		lbound.setColumns(10);
		
		JLabel lblMinlimit = new JLabel("min_limit");
		lblMinlimit.setBounds(67, 125, 70, 15);
		frame.getContentPane().add(lblMinlimit);
		
		ubound = new JTextField();
		ubound.setBackground(new Color(255, 255, 204));
		ubound.setBounds(220, 166, 114, 19);
		frame.getContentPane().add(ubound);
		ubound.setColumns(10);
		
		JLabel lblMaxlimit = new JLabel("max_limit");
		lblMaxlimit.setBounds(67, 168, 70, 15);
		frame.getContentPane().add(lblMaxlimit);
		
		head = new JTextField();
		head.setBackground(new Color(255, 255, 204));
		head.setBounds(220, 217, 114, 19);
		frame.getContentPane().add(head);
		head.setColumns(10);
		
		JLabel lblHeadpointer = new JLabel("head_pointer");
		lblHeadpointer.setBounds(53, 219, 125, 15);
		frame.getContentPane().add(lblHeadpointer);
		
		JRadioButton rdbtnDfcfs = new JRadioButton("dfcfs");
		rdbtnDfcfs.setBackground(new Color(0, 51, 204));
		rdbtnDfcfs.setBounds(45, 271, 95, 23);
		frame.getContentPane().add(rdbtnDfcfs);
		
		JRadioButton rdbtnSstf = new JRadioButton("sstf");
		rdbtnSstf.setBackground(new Color(0, 0, 204));
		rdbtnSstf.setBounds(45, 298, 95, 23);
		frame.getContentPane().add(rdbtnSstf);
		
		JRadioButton rdbtnScan = new JRadioButton("scan");
		rdbtnScan.setBackground(new Color(0, 0, 204));
		rdbtnScan.setBounds(167, 271, 102, 23);
		rdbtnScan.setText("scan");
		frame.getContentPane().add(rdbtnScan);
		
		JRadioButton rdbtnCscan = new JRadioButton("cscan");
		rdbtnCscan.setBackground(new Color(0, 0, 204));
		rdbtnCscan.setBounds(167, 298, 102, 23);
		frame.getContentPane().add(rdbtnCscan);
		
		JRadioButton rdbtnLook = new JRadioButton("look");
		rdbtnLook.setBackground(new Color(0, 0, 204));
		rdbtnLook.setBounds(274, 271, 149, 23);
		frame.getContentPane().add(rdbtnLook);
		
		JRadioButton rdbtnClook = new JRadioButton("clook");
		rdbtnClook.setBackground(new Color(0, 0, 204));
		rdbtnClook.setBounds(274, 298, 149, 23);
		frame.getContentPane().add(rdbtnClook);
		
		ButtonGroup group=new ButtonGroup();
		group.add(rdbtnScan);
		group.add(rdbtnDfcfs);
		group.add(rdbtnSstf);
		group.add(rdbtnCscan);
		group.add(rdbtnLook);
		group.add(rdbtnClook);
		
		
		
		
		JButton btnSubmit = new JButton("submit");
		btnSubmit.setBackground(new Color(153, 51, 204));
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				disk_main sc=new disk_main();
				disk_sec t=new disk_sec();
				Random rand=new Random();
				//String no =no_of_sec.getText();
				int i;
				 n=Integer.parseInt(no_of_sec.getText());
				 min=Integer.parseInt(lbound.getText());
				 max=Integer.parseInt(ubound.getText());
				 hpointer=Integer.parseInt(head.getText());
				int a1[]=new int[n];
				df=new int[n];
				boolean status;
				for(i=0;i<n;i++)
				{
					int p=rand.nextInt(100);
					status=not_avail(a1,i,p);
					if(p>min&&p<max&&status==true)
					{
						a1[i]=p;
						df[i]=p;
						
						t.inp_array.append(String.valueOf(a1[i]+" "));
					}
					else
					{
							while(true)
							{
								p=rand.nextInt(100);
								status=not_avail(a1,i,p);
								if(p>min&&p<max&&status==true);
								{
									a1[i]=p;
									df[i]=p;
									break;
								}
							}
							t.inp_array.append(String.valueOf(a1[i]+" "));
					}
				}
				
				t.jp=new JScrollPane(t.inp_array);
				t.frame.getContentPane().add(t.jp);
				t.jp.setBounds(122, 12, 264, 77);
				String s=unibutton(group);
				if(s=="dfcfs")
				{	
					 k=sc.dfcfs(a1,n,hpointer,min,max);
					 for(i=0;i<n;i++)
						{
							t.output.append(String.valueOf(sc.seq[i])+" ");
						}
					 t.oup1=new JScrollPane(t.output);
						t.frame.getContentPane().add(t.oup1);
						t.oup1.setBounds(122, 116, 259, 77);
				}
				if(s=="sstf")
				{
					k=sc.dsstf(a1, n, hpointer, min, max);
					for(i=0;i<n;i++)
					{
						t.output.append(String.valueOf(sc.seq[i])+" ");
					}
					t.oup2=new JScrollPane(t.output);
					t.frame.getContentPane().add(t.oup2);
					t.oup2.setBounds(179, 172, 259, 77);
				}
				if(s=="scan")
				{
					k=sc.dscan(a1,n,hpointer,min,max);
					for(i=0;i<sc.b1.size();i++)
					{
						t.output.append(String.valueOf(sc.b1.get(i))+" ");
					}
					t.oup3=new JScrollPane(t.output);
					t.frame.getContentPane().add(t.oup3);
					t.oup3.setBounds(179, 172, 259, 77);
				}
				if(s=="cscan")
				{
					k=sc.dcscan(a1,n,hpointer,min,max);
					for(i=0;i<n+3;i++)
					{
						t.output.append(String.valueOf(sc.b2.get(i))+" ");
					}
					t.oup4=new JScrollPane(t.output);
					t.frame.getContentPane().add(t.oup4);
					t.oup4.setBounds(179, 172, 259, 77);
				}
				if(s=="look")
				{
					k=sc.look(a1,n,hpointer,min,max);
					t.oup5=new JScrollPane(t.output);
					t.frame.getContentPane().add(t.oup5);
					for(i=0;i<sc.n1.size();i++)
					{
						t.output.append(String.valueOf(sc.n1.get(i))+" ");
			
					}
					t.oup5.setBounds(179, 172, 259, 77);
				}
				if(s=="clook")
				{
					k=sc.clook(a1, n, hpointer, min, max);
					t.oup6=new JScrollPane(t.output);
					t.oup6.setBounds(179, 172, 259, 77);
					t.frame.getContentPane().add(t.oup6);
					for(i=0;i<sc.a1.size();i++)
					{
						t.output.append(String.valueOf(sc.a1.get(i))+" ");
			
					}
				
				}
				t.txtHiran.setText(String.valueOf(k));
				t.txtHiran.setEditable(false);
				t.frame.setVisible(true);
		
		
		
		}});
		btnSubmit.setBounds(149, 356, 117, 25);
		frame.getContentPane().add(btnSubmit);
	}
}