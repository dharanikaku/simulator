package END_PROJCT;
//package org.jfree.chart.demo;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.general.PieDataset;
import org.jfree.ui.ApplicationFrame;
//import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Rotation;


public class disk_four extends ApplicationFrame {

    
	public JFrame frame=new JFrame();
	private static final long serialVersionUID = 1L;

    public disk_four() {

        super("you");

        
        JPanel chartPanel = createChart();
        
       
        chartPanel.setPreferredSize(new java.awt.Dimension(100, 200));
        //setContentPane(chartPanel);
        frame.setBounds(100, 100, 640, 480);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.getContentPane().add(chartPanel);
        frame.setVisible(true);

    }
    
    
    private PieDataset createSampleDataset() {
    	//disk_sec e=new disk_sec();
    	
        String p1="FCFS"+" - "+String.valueOf(disk_sec.c1);
        String p2="SSFT"+" - "+String.valueOf(disk_sec.c2);
        String p3="SCAN"+" - "+String.valueOf(disk_sec.c3);
        String p4="CSCAN"+" - "+String.valueOf(disk_sec.c4);
        String p5="LOOK"+" - "+String.valueOf(disk_sec.c5);
        String p6="CLOOK"+" - "+String.valueOf(disk_sec.c6);
        
    	DefaultPieDataset result = new DefaultPieDataset();
    //System.out.println("%%%%% "+disk_sec.c1);
        result.setValue(p1, disk_sec.c1);
        result.setValue(p2, disk_sec.c2);
        result.setValue(p3, disk_sec.c3);
        result.setValue(p4, disk_sec.c4);
        result.setValue(p5, disk_sec.c5);
        result.setValue(p6, disk_sec.c6);
        return result;
        
    }
    
    
   


	public JPanel createChart() {
    	
        
        PieDataset dataset=createSampleDataset();

        JFreeChart chart = ChartFactory.createPieChart3D(
            "Comparision of all disk algorithms",  // chart title
            dataset,                // data
            true,                   // include legend
            true,
            false
        );
        final PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        plot.setNoDataMessage("No data to display");
        return new ChartPanel(chart);
        
    }
    
   
    public void req() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
            	try {
					disk_four window = new disk_four();
					window.frame.setVisible(true);
					window.setVisible(true);
					//window.pack();
			        //RefineryUtilities.centerFrameOnScreen(window);
				} catch (Exception e) {
					e.printStackTrace();
				}
                
            }
        });
}
}