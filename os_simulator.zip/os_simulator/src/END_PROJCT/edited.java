package END_PROJCT;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadLocalRandom;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.SwingUtilities;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Label;
import java.awt.Font;

public class edited extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel jLabel;
	private JLabel jLabel1;
	public JFrame frame=new JFrame();
	
	
	
	
	
	// private int l;
	// Queue<Integer> queue=new LinkedList<Integer>();
	// int a,b,k,k1,i,h,l;

	int phil[] = new int[5];
	private Timer timer;
	private boolean chromeShown;
	private int x;
	private int m;
	private int n;
	private int flag[] = new int[5];

	public edited() {
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setSize(930, 693);
		
		
		
		JMenuBar bar=new JMenuBar();
		JMenu file,process,dinning,page,disk,help;
		JMenuItem exiti,homei,processi,dinningi,pagei,diski,helpi;
		
		file=new JMenu("File");
		process=new JMenu("Process");
		dinning=new JMenu("Dinning");
		page=new JMenu("Page");
		disk=new JMenu("Disk");
		help=new JMenu("Help");
		bar.add(file);
		bar.add(process);
		bar.add(dinning);
		bar.add(page);
		bar.add(disk);
		bar.add(help);
		ImageIcon si11=new ImageIcon("/home/indian/Documents/exit.png");
		ImageIcon si12=new ImageIcon("/home/indian/Documents/blue-home-icon.png");
		ImageIcon si4=new ImageIcon("/home/indian/Documents/disk1.png");
		exiti=new JMenuItem("Exit",si11);
		
		homei=new JMenuItem("Home",si12);
		homei.setMnemonic(KeyEvent.VK_H);
		processi=new JMenuItem("CPU Scheduling");
		dinningi=new JMenuItem("Dinning Philosophers");
		pagei=new JMenuItem("Page Replacement");
		diski=new JMenuItem("Disk Management",si4);
		helpi=new JMenuItem("Help");
		file.add(exiti);
		file.add(homei);
		process.add(processi);
		dinning.add(dinningi);
		page.add(pagei);
		disk.add(diski);
		diski.setMnemonic(KeyEvent.VK_D);
		help.add(helpi);
		this.setJMenuBar(bar);
		
		
		
		exiti.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				quit();
			}
		});

diski.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				//disk_first ds1=new disk_first();
				//ds1.req();
			}
		});
processi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		a_start a1=new a_start();
		a1.req();
	}
});
dinningi.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		edited z=new edited();
		z.req();
	}
});
pagei.addActionListener(new ActionListener()
{
	public void actionPerformed(ActionEvent e)
	{
		page_first pf=new page_first();
		pf.req();
	}
});
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(216, 191, 216));

		jLabel = new JLabel(new ImageIcon("right1.png"));
		chromeShown = true;
		x = 0;
		m = 0;
		panel.setLayout(null);
		panel.add(jLabel);

		this.getContentPane().add(panel);

		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("phi2.png"));
		label_1.setBounds(345, 71, 119, 166);
		panel.add(label_1);

		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon("side1.png"));
		label_2.setBounds(178, 232, 119, 134);
		panel.add(label_2);

		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon("User.png"));
		label_3.setBounds(263, 426, 128, 117);
		panel.add(label_3);

		JLabel label_4 = new JLabel("");
		label_4.setIcon(new ImageIcon("right1.png"));
		label_4.setBounds(569, 238, 107, 128);
		panel.add(label_4);

		JLabel label_5 = new JLabel("");
		label_5.setIcon(new ImageIcon("right1.png"));
		label_5.setBounds(469, 406, 100, 166);
		panel.add(label_5);

		Label lblPhi_1 = new Label("THINKING");
		lblPhi_1.setFont(new Font("Serif", Font.BOLD, 14));
		lblPhi_1.setAlignment(Label.CENTER);
		lblPhi_1.setBackground(new Color(0, 0, 255));
		lblPhi_1.setBounds(569, 447, 89, 22);
		panel.add(lblPhi_1);

		Label lblPhi_2 = new Label("THINKING");
		lblPhi_2.setFont(new Font("Serif", Font.BOLD, 14));
		lblPhi_2.setAlignment(Label.CENTER);
		lblPhi_2.setBackground(new Color(0, 0, 255));
		lblPhi_2.setBounds(682, 256, 89, 22);
		panel.add(lblPhi_2);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon("whitespoon - Copy (2).png"));
		lblNewLabel.setBounds(307, 201, 100, 90);
		panel.add(lblNewLabel);

		JLabel label_6 = new JLabel("");
		label_6.setIcon(new ImageIcon("whitespoon.png"));
		label_6.setBounds(263, 359, 119, 77);
		panel.add(label_6);

		JLabel label_7 = new JLabel("");
		label_7.setIcon(new ImageIcon("strspoon.png"));
		label_7.setBounds(401, 409, 46, 89);
		panel.add(label_7);

		JLabel label_8 = new JLabel("");
		label_8.setIcon(new ImageIcon(""));
		// whitespoon - Copy.png
		label_8.setBounds(494, 278, 148, 117);
		panel.add(label_8);

		JLabel label_9 = new JLabel("");
		label_9.setIcon(new ImageIcon("whitespoon - Copy (3).png"));
		label_9.setBounds(457, 202, 119, 89);
		panel.add(label_9);

		JLabel label_15 = new JLabel("");
		label_15.setIcon(new ImageIcon(""));
		// whitespoon - Copy (2).png
		label_15.setBounds(277, 248, 69, 64);
		panel.add(label_15);

		JLabel label_16 = new JLabel("");
		label_16.setIcon(new ImageIcon(""));
		// whitespoon.png
		label_16.setBounds(266, 302, 89, 98);
		panel.add(label_16);

		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("food00.jpg"));
		label.setBounds(307, 290, 74, 58);
		panel.add(label);

		JLabel label_14 = new JLabel("");
		label_14.setIcon(new ImageIcon(""));
		// whitespoon.png
		label_14.setBounds(280, 384, 69, 86);
		panel.add(label_14);

		JLabel label_17 = new JLabel("");
		label_17.setIcon(new ImageIcon(""));
		// whitespoon - Copy.png
		label_17.setBounds(352, 406, 81, 77);
		panel.add(label_17);

		JLabel label_13 = new JLabel("");
		label_13.setIcon(new ImageIcon("food00.jpg"));
		label_13.setBounds(322, 375, 69, 61);
		panel.add(label_13);

		JLabel label_18 = new JLabel("");
		label_18.setIcon(new ImageIcon(""));
		// whitespoon.png
		label_18.setBounds(434, 394, 72, 89);
		panel.add(label_18);

		JLabel label_19 = new JLabel("");
		label_19.setIcon(new ImageIcon(""));
		// whitespoon - Copy.png

		label_19.setBounds(504, 384, 66, 90);
		panel.add(label_19);

		JLabel label_12 = new JLabel("");
		label_12.setIcon(new ImageIcon("food00.jpg"));
		label_12.setBounds(457, 379, 74, 71);
		panel.add(label_12);

		JLabel label_20 = new JLabel("");
		label_20.setIcon(new ImageIcon("whitespoon - Copy.png"));

		label_20.setBounds(494, 277, 123, 193);
		panel.add(label_20);

		JLabel label_21 = new JLabel("");
		label_21.setIcon(new ImageIcon(""));
		// whitespoon - Copy (3).png
		label_21.setBounds(485, 197, 157, 151);
		panel.add(label_21);

		JLabel label_11 = new JLabel("");
		label_11.setIcon(new ImageIcon("food00.jpg"));
		label_11.setBounds(477, 277, 69, 64);
		panel.add(label_11);

		JLabel label_22 = new JLabel("");
		label_22.setIcon(new ImageIcon(""));
		label_22.setBounds(345, 176, 111, 89);
		// whitespoon - Copy (2).png
		panel.add(label_22);

		JLabel label_23 = new JLabel("");
		label_23.setIcon(new ImageIcon(""));
		// whitespoon - Copy (3).png
		label_23.setBounds(417, 176, 64, 75);
		panel.add(label_23);

		JLabel label_24 = new JLabel("");
		label_24.setIcon(new ImageIcon("food00.jpg"));
		label_24.setBounds(381, 220, 66, 58);
		panel.add(label_24);

		JLabel label_10 = new JLabel("");
		label_10.setIcon(new ImageIcon("table.png"));
		label_10.setBounds(294, 162, 382, 347);
		panel.add(label_10);

		JLabel lblDiningPhilosophers = new JLabel("DINING PHILOSOPHERS");
		lblDiningPhilosophers.setBackground(new Color(245, 222, 179));
		lblDiningPhilosophers.setFont(new Font("Poor Richard", Font.BOLD, 20));
		lblDiningPhilosophers.setForeground(new Color(72, 61, 139));
		lblDiningPhilosophers.setBounds(352, 11, 306, 24);
		panel.add(lblDiningPhilosophers);

		Label lblPhi = new Label("THINKING");
		lblPhi.setFont(new Font("Serif", Font.BOLD, 14));
		lblPhi.setAlignment(Label.CENTER);
		lblPhi.setBackground(new Color(0, 0, 255));
		lblPhi.setBounds(178, 467, 89, 22);
		panel.add(lblPhi);

		JLabel lblNewLabel_1 = new JLabel("PHILOSOPHER 1");
		lblNewLabel_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblNewLabel_1.setForeground(new Color(139, 0, 139));
		lblNewLabel_1.setBounds(460, 71, 116, 14);
		panel.add(lblNewLabel_1);

		JLabel lblPhilosopher = new JLabel("PHILOSOPHER 2");
		lblPhilosopher.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblPhilosopher.setForeground(new Color(128, 0, 128));
		lblPhilosopher.setBounds(89, 223, 111, 14);
		panel.add(lblPhilosopher);

		JLabel lblPhilosopher_1 = new JLabel("PHILOSOPHER 3");
		lblPhilosopher_1.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblPhilosopher_1.setForeground(new Color(139, 0, 139));
		lblPhilosopher_1.setBounds(150, 439, 128, 22);
		panel.add(lblPhilosopher_1);

		Label lbl = new Label("THINKING");
		lbl.setFont(new Font("Serif", Font.BOLD, 14));
		lbl.setAlignment(Label.CENTER);
		lbl.setBackground(new Color(0, 0, 255));
		lbl.setBounds(457, 91, 112, 22);
		panel.add(lbl);

		Label lblNewLabel_3 = new Label("THINKING");
		lblNewLabel_3.setFont(new Font("Serif", Font.BOLD, 14));
		lblNewLabel_3.setAlignment(Label.CENTER);
		lblNewLabel_3.setBackground(new Color(0, 0, 255));
		lblNewLabel_3.setBounds(78, 243, 100, 22);
		panel.add(lblNewLabel_3);

		JLabel lblPhilosopher_2 = new JLabel("PHILOSOPHER 5");
		lblPhilosopher_2.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblPhilosopher_2.setForeground(new Color(128, 0, 128));
		lblPhilosopher_2.setBounds(682, 232, 136, 19);
		panel.add(lblPhilosopher_2);

		JLabel lblPhilosopher_3 = new JLabel("PHILOSOPHER 4");
		lblPhilosopher_3.setFont(new Font("Tempus Sans ITC", Font.BOLD, 13));
		lblPhilosopher_3.setForeground(new Color(128, 0, 128));
		lblPhilosopher_3.setBounds(569, 418, 141, 22);
		panel.add(lblPhilosopher_3);
		this.setVisible(true);

		JButton btnStop = new JButton("EXIT");
		btnStop.setBackground(new Color(0, 0, 0));
		btnStop.setForeground(new Color(102, 205, 170));
		btnStop.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				/*
				 * lbl.setText("THINKING"); lblNewLabel_3.setText("THINKING");
				 * lblPhi.setText("THINKING"); lblPhi_1.setText("THINKING");
				 * lblPhi_2.setText("THINKING");
				 */
				JOptionPane.showMessageDialog(frame, "Are you sure to exit?");
				System.exit(JFrame.EXIT_ON_CLOSE);
				//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

			}
		});
		btnStop.setBounds(682, 582, 89, 23);
		panel.add(btnStop);
		this.setVisible(true);

		JButton btnStart = new JButton("START");
		btnStart.setBackground(new Color(0, 0, 0));
		btnStart.setForeground(new Color(64, 224, 208));
		btnStart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int interval = 5000; // repeating every 1000 ms
				new Timer(interval, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {

						int i, j, k;
						String Output = new String();
						String string = new String();
						String k1 = new String();
						String string1 = new String();
						string = "x";
						int temp = 0, size;
						Queue<Integer> queue = new LinkedList<Integer>();
						Queue<String> q = new LinkedList<String>();
						Random random = new Random();
						int Thinking_Time[] = new int[6];
						int Eating_Time[] = new int[6];
						String Action[] = new String[6];
						for (i = 1; i <= 5; i++) {
							Action[i] = "THINKING";
						}
						for (i = 1; i <= 5; i++) {
							Thinking_Time[i] = random.nextInt(5) + 1;
							Eating_Time[i] = -1;
						}
						for (i = 0; i <= 20; i++) {

							for (j = 1; j <= 5; j++) {
								if (Eating_Time[j] > 0) {
									Eating_Time[j] = Eating_Time[j] - 1;
									if (Eating_Time[j] == 0) {
										Eating_Time[j] = -1;
										Thinking_Time[j] = random.nextInt(5) + 1;
										Action[j] = "THINKING";
									}
								}
							}
							temp = 0;
							for (j = 1; j <= 5; j++) {
								if (Thinking_Time[j] == 0) {
									queue.add(j);
									q.add(string);
									Action[j] = "HUNGRY  ";
									temp = 1;
								}
							}
							int flag;
							if (temp == 1) {
								if (string == "x") {
									string = "y";
								} else {
									string = "x";
								}
							}
							if (queue.size() != 0) {
								string1 = q.peek();
							}
							flag = 0;
							if (queue.size() != 0) {
								size = queue.size();
								k = queue.peek();
								k1 = q.peek();
								for (int z = 1; z <= size; z++) {
									flag = 0;
									if (k == 1) {
										if (Action[k] == "HUNGRY  " && Action[5] != "EATING  "
												&& Action[2] != "EATING  ") {
											Action[k] = "EATING  ";
											Eating_Time[k] = random.nextInt(5) + 1;
											flag = 1;
										}
									} else if (k == 4) {
										if (Action[k] == "HUNGRY  " && Action[3] != "EATING  "
												&& Action[5] != "EATING  ") {
											Action[k] = "EATING  ";
											Eating_Time[k] = random.nextInt(5) + 1;
											flag = 1;
										}
									} else if (Action[k] == "HUNGRY  " && Action[k - 1] != "EATING  "
											&& Action[(k + 1) % 5] != "EATING  ") {
										Action[k] = "EATING  ";
										Eating_Time[k] = random.nextInt(5) + 1;
										flag = 1;
									}
									if (flag == 1) {
										queue.poll();
										q.poll();
									} else {
										queue.add(queue.remove());
										q.add(q.remove());
									}
									if (q.peek() != string1 && z == 1) {
										int y;
										if (queue.size() != 0) {
											for (y = z + 1; y <= size; y++) {
												queue.add(queue.remove());
												q.add(q.remove());
											}
										}
										break;
									} else if (q.peek() != string1) {
										int y;
										if (queue.size() != 0) {
											for (y = z + 1; y <= size; y++) {
												queue.add(queue.remove());
												q.add(q.remove());
											}
										}
										break;
									}
									k = queue.peek();
									k1 = q.peek();
								}
							}
							Output = "";
							for (j = 1; j <= 5; j++) {
								Thinking_Time[j] = Thinking_Time[j] - 1;
								Output = Output + Action[j] + ' ';
							}
							System.out.println(Output + "\n");
							try {
								Thread.sleep(0000);
							} catch (InterruptedException e1) {
								System.out.println(e1);
							}
							lbl.setText(Action[1]);
							lblNewLabel_3.setText(Action[2]);
							lblPhi.setText(Action[3]);
							lblPhi_1.setText(Action[4]);
							lblPhi_2.setText(Action[5]);
							int l;
							for (l = 1; l <= 5; l++) {
								if (Action[l] == "EATING  ") {
									if (l == 1) {

										lblNewLabel.setIcon(new ImageIcon(""));
										lbl.setBackground(new Color(0, 255, 0));
										label_22.setIcon(new ImageIcon(
												"whitespoon - Copy (2).png"));
										label_9.setIcon(new ImageIcon(""));
										label_23.setIcon(new ImageIcon(
												"whitespoon - Copy (3).png"));

										// label_24.setIcon(new
										// ImageIcon("food2.jpg"));

										label_24.setIcon(new ImageIcon("food6.jpg"));

										// label_24.setIcon(new
										// ImageIcon("food00.jpg"));

									}
									if (l == 2) {
										lblNewLabel_3.setBackground(new Color(0, 255, 0));
										lblNewLabel.setIcon(new ImageIcon(""));
										label_15.setIcon(new ImageIcon(
												"whitespoon - Copy (2).png"));
										label_6.setIcon(new ImageIcon(""));
										label_16.setIcon(new ImageIcon("whitespoon.png"));
										label.setIcon(new ImageIcon("food6.jpg"));

									}
									if (l == 3) {
										// label_24.setIcon(new
										// ImageIcon("food00.jpg"));
										label_13.setIcon(new ImageIcon("food6.jpg"));
										lblPhi.setBackground(new Color(0, 255, 0));
										label_6.setIcon(new ImageIcon(""));
										label_14.setIcon(new ImageIcon("whitespoon.png"));
										label_7.setIcon(new ImageIcon(""));
										label_17.setIcon(
												new ImageIcon("whitespoon - Copy.png"));
									}
									if (l == 4) {
										// label_24.setIcon(new
										// ImageIcon("food00.jpg"));
										label_12.setIcon(new ImageIcon("food6.jpg"));
										lblPhi_1.setBackground(new Color(0, 255, 0));
										label_7.setIcon(new ImageIcon(""));
										label_18.setIcon(new ImageIcon("whitespoon.png"));
										label_20.setIcon(new ImageIcon(""));
										label_19.setIcon(
												new ImageIcon("whitespoon - Copy.png"));
									}
									if (l == 5) {
										// label_24.setIcon(new
										// ImageIcon("food00.jpg"));
										label_11.setIcon(new ImageIcon("food6.jpg"));
										lblPhi_2.setBackground(new Color(0, 255, 0));
										label_20.setIcon(new ImageIcon(""));
										label_8.setIcon(
												new ImageIcon("whitespoon - Copy.png"));
										label_9.setIcon(new ImageIcon(""));
										label_21.setIcon(new ImageIcon(
												"whitespoon - Copy (3).png"));
									}
								}
								if (Action[l] == "THINKING") {
									if (l == 1) {

										lbl.setBackground(new Color(0, 0, 255));

										if (Action[2] == "EATING  " && Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											lblNewLabel.setIcon(new ImageIcon(""));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_23.setIcon(new ImageIcon(""));

										} else if (Action[2] == "EATING  ") {
											label_24.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label.setIcon(new ImageIcon("food6.jpg"));
											lblNewLabel.setIcon(new ImageIcon(""));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_23.setIcon(new ImageIcon(""));
										} else if (Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_24.setIcon(new ImageIcon("food00.jpg"));
											// label.setIcon(new
											// ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_23.setIcon(new ImageIcon(""));
										} else {
											label_24.setIcon(new ImageIcon("food00.jpg"));
											// label.setIcon(new
											// ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_23.setIcon(new ImageIcon(""));
										}
									}
									if (l == 2) {
										lblNewLabel_3.setBackground(new Color(0, 0, 255));
										if (Action[1] == "EATING  " && Action[3] == "EATING  ") {
											lblPhi.setBackground(new Color(0, 255, 0));
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));

											lblNewLabel.setIcon(new ImageIcon(""));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(new ImageIcon(""));
											label_16.setIcon(new ImageIcon(""));
										} else if (Action[1] == "EATING  ") {
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));

											lblNewLabel.setIcon(new ImageIcon(""));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_16.setIcon(new ImageIcon(""));
										} else if (Action[3] == "EATING  ") {
											lblPhi.setBackground(new Color(0, 255, 0));
											// ))label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));

											label.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(new ImageIcon(""));
											label_16.setIcon(new ImageIcon(""));
										} else {

											// ))label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_16.setIcon(new ImageIcon(""));
										}
									}
									if (l == 3) {
										lblPhi.setBackground(new Color(0, 0, 255));
										if (Action[2] == "EATING  " && Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_6.setIcon(new ImageIcon(""));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(new ImageIcon(""));
											label_17.setIcon(new ImageIcon(""));

										} else if (Action[2] == "EATING  ") {
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_6.setIcon(new ImageIcon(""));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_17.setIcon(new ImageIcon(""));

										} else if (Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											// ))label.setIcon(new
											// ImageIcon("food00.jpg"));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(new ImageIcon(""));
											label_17.setIcon(new ImageIcon(""));
										} else {
											label_13.setIcon(new ImageIcon("food00.jpg"));
											// ))label.setIcon(new
											// ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_17.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_14.setIcon(new ImageIcon(""));
										}
									}
									if (l == 4) {
										// ))label_24.setIcon(new
										// ImageIcon("food00.jpg"));
										// ))label.setIcon(new
										// ImageIcon("food00.jpg"));
										lblPhi_1.setBackground(new Color(0, 0, 255));
										if (Action[3] == "EATING  " && Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											lblPhi.setBackground(new Color(0, 255, 0));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											// label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_7.setIcon(new ImageIcon(""));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(""));
											label_19.setIcon(new ImageIcon(""));

										} else if (Action[3] == "EATING  ") {
											label_13.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											lblPhi.setBackground(new Color(0, 255, 0));
											label_7.setIcon(new ImageIcon(""));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_19.setIcon(new ImageIcon(""));

										} else if (Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(""));
											label_19.setIcon(new ImageIcon(""));
										} else {
											label_12.setIcon(new ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_19.setIcon(new ImageIcon(""));
										}
									}
									if (l == 5) {
										lblPhi_2.setBackground(new Color(0, 0, 255));
										// ))label.setIcon(new
										// ImageIcon("food00.jpg"));
										label_11.setIcon(new ImageIcon("food00.jpg"));
										if (Action[4] == "EATING  " && Action[1] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_20.setIcon(new ImageIcon(""));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_21.setIcon(new ImageIcon(""));

										} else if (Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));

											label_20.setIcon(new ImageIcon(""));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_21.setIcon(new ImageIcon(""));
											label_12.setIcon(new ImageIcon("food6.jpg"));
										} else if (Action[1] == "EATING  ") {
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_21.setIcon(new ImageIcon(""));
										} else {
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_21.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_8.setIcon(new ImageIcon(""));
										}
									}
								}

								if (Action[l] == "HUNGRY  ") {
									if (l == 1) {
										lbl.setBackground(new Color(255, 0, 0));
										if (Action[2] == "EATING  " && Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											lblNewLabel.setIcon(new ImageIcon(""));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_23.setIcon(new ImageIcon(""));

										} else if (Action[2] == "EATING  ") {
											label_24.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label.setIcon(new ImageIcon("food6.jpg"));
											lblNewLabel.setIcon(new ImageIcon(""));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_23.setIcon(new ImageIcon(""));
										} else if (Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_24.setIcon(new ImageIcon("food00.jpg"));
											// label.setIcon(new
											// ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_23.setIcon(new ImageIcon(""));
										} else {
											label_24.setIcon(new ImageIcon("food00.jpg"));
											// label.setIcon(new
											// ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_22.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_23.setIcon(new ImageIcon(""));
										}
									}
									if (l == 2) {
										lblNewLabel_3.setBackground(new Color(255, 0, 0));
										if (Action[1] == "EATING  " && Action[3] == "EATING  ") {
											lblPhi.setBackground(new Color(0, 255, 0));
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));

											lblNewLabel.setIcon(new ImageIcon(""));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(new ImageIcon(""));
											label_16.setIcon(new ImageIcon(""));
										} else if (Action[1] == "EATING  ") {
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));

											lblNewLabel.setIcon(new ImageIcon(""));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_16.setIcon(new ImageIcon(""));
										} else if (Action[3] == "EATING  ") {
											lblPhi.setBackground(new Color(0, 255, 0));
											// ))label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));

											label.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(new ImageIcon(""));
											label_16.setIcon(new ImageIcon(""));
										} else {

											// ))label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food00.jpg"));
											lblNewLabel.setIcon(new ImageIcon(
													"whitespoon - Copy (2).png"));
											label_15.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_16.setIcon(new ImageIcon(""));
										}
									}
									if (l == 3) {
										lblPhi.setBackground(new Color(255, 0, 0));
										if (Action[2] == "EATING  " && Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_6.setIcon(new ImageIcon(""));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(new ImageIcon(""));
											label_17.setIcon(new ImageIcon(""));

										} else if (Action[2] == "EATING  ") {
											lblNewLabel_3.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											label.setIcon(new ImageIcon("food6.jpg"));
											label_6.setIcon(new ImageIcon(""));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_17.setIcon(new ImageIcon(""));

										} else if (Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											label_13.setIcon(new ImageIcon("food00.jpg"));
											// ))label.setIcon(new
											// ImageIcon("food00.jpg"));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_14.setIcon(new ImageIcon(""));
											label_7.setIcon(new ImageIcon(""));
											label_17.setIcon(new ImageIcon(""));
										} else {
											label_13.setIcon(new ImageIcon("food00.jpg"));
											// ))label.setIcon(new
											// ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_17.setIcon(new ImageIcon(""));
											label_6.setIcon(
													new ImageIcon("whitespoon.png"));
											label_14.setIcon(new ImageIcon(""));
										}
									}
									if (l == 4) {
										// ))label_24.setIcon(new
										// ImageIcon("food00.jpg"));
										// ))label.setIcon(new
										// ImageIcon("food00.jpg"));
										lblPhi_1.setBackground(new Color(255, 0, 0));
										if (Action[3] == "EATING  " && Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											lblPhi.setBackground(new Color(0, 255, 0));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											// label_24.setIcon(new
											// ImageIcon("food00.jpg"));
											label_13.setIcon(new ImageIcon("food6.jpg"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_7.setIcon(new ImageIcon(""));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(""));
											label_19.setIcon(new ImageIcon(""));

										}

										else if (Action[3] == "EATING  ") {
											label_13.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											lblPhi.setBackground(new Color(0, 255, 0));
											label_7.setIcon(new ImageIcon(""));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_19.setIcon(new ImageIcon(""));

										} else if (Action[5] == "EATING  ") {
											lblPhi_2.setBackground(new Color(0, 255, 0));
											label_12.setIcon(new ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_11.setIcon(new ImageIcon("food6.jpg"));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(""));
											label_19.setIcon(new ImageIcon(""));
										} else {
											label_12.setIcon(new ImageIcon("food00.jpg"));
											label_7.setIcon(
													new ImageIcon("strspoon.png"));
											label_18.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_19.setIcon(new ImageIcon(""));
										}
									}
									if (l == 5) {
										lblPhi_2.setBackground(new Color(255, 0, 0));
										// ))label.setIcon(new
										// ImageIcon("food00.jpg"));
										label_11.setIcon(new ImageIcon("food00.jpg"));
										if (Action[4] == "EATING  " && Action[1] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label_12.setIcon(new ImageIcon("food6.jpg"));
											label_20.setIcon(new ImageIcon(""));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_21.setIcon(new ImageIcon(""));

										} else if (Action[4] == "EATING  ") {
											lblPhi_1.setBackground(new Color(0, 255, 0));
											label_20.setIcon(new ImageIcon(""));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_21.setIcon(new ImageIcon(""));
											label_12.setIcon(new ImageIcon("food6.jpg"));
										} else if (Action[1] == "EATING  ") {
											lbl.setBackground(new Color(0, 255, 0));
											label_24.setIcon(new ImageIcon("food6.jpg"));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_8.setIcon(new ImageIcon(""));
											label_9.setIcon(new ImageIcon(""));
											label_21.setIcon(new ImageIcon(""));
										} else {
											label_9.setIcon(new ImageIcon(
													"whitespoon - Copy (3).png"));
											label_21.setIcon(new ImageIcon(""));
											label_20.setIcon(new ImageIcon(
													"whitespoon - Copy.png"));
											label_8.setIcon(new ImageIcon(""));
										}
									}
								}

							}
						}
						// do whatever painting that you want
					}
				}).start();

			}

		});
		btnStart.setBounds(118, 26, 89, 23);
		panel.add(btnStart);
		
		frame.addWindowListener(new WindowAdapter() {
		      @Override
		      public void windowClosing(WindowEvent event) {
		        quit();
		      }
		    });
	}
		
		void quit() {
		    if (JOptionPane.showConfirmDialog(
		      frame,
		      "Are you sure you want to exit?",
		      "Please confirm",
		      JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION
		    ) {
		      frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		    }
		  }

	

	public  void req() {
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				edited window=new edited();
				window.frame.setVisible(true);
				
			}
		});

	}
}