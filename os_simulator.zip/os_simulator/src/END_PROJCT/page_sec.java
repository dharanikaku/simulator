package END_PROJCT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class page_sec{

	public JFrame frame;
	//public JTable table1;
	public JScrollPane scrollpane1;
	public JTextArea textArea;
	public JTable frtable;
	JTextField count;
	/**
	 * Launch the application.
	 */
	public  void gui2() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					page_sec window = new page_sec();
					window.frame.setVisible(true);
					
					
					/*pagerepalce pr=new pagerepalce();
					String ss[]= new String[3];
					int i,j;
					for(i=0;i<3;i++)
					{
						ss[i]=String.valueOf(i);
					}
					//obj=new String[20][20];
					for(i=0;i<20;i++)
					{
						for(j=0;j<3;j++)
						{
							System.out.println("^^^ "+pr.bb[i][j]);
						}
					}
					 table1 = new JTable(pr.bb,ss);
					 scrollpane1=new JScrollPane(table1);

					scrollpane1.setBounds(77, 279, 364, 130);
					frame.getContentPane().add(scrollpane1);
					scrollpane1.setVisible(true);*/
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public page_sec() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 556, 445);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		
		
		JLabel lblPages = new JLabel("pages");
		lblPages.setBounds(37, 26, 70, 15);
		frame.getContentPane().add(lblPages);
		
		JLabel lblTotalNumberOf = new JLabel("Total number of faults ");
		lblTotalNumberOf.setBounds(33, 93, 173, 15);
		frame.getContentPane().add(lblTotalNumberOf);
		
		/*count = new JTextField();
		count.setBounds(220, 91, 114, 19);
		frame.getContentPane().add(count);
		count.setColumns(10);*/
		page_first pp=new page_first();
		/*int i;
		for(i=0;i<pp.n;i++)
		{
		textArea.append(String.valueOf(pp.a[i])+" ");
		}*/
		
		/*JTextArea textArea = new JTextArea();
		textArea.setBounds(145, 12, 279, 51);
		frame.getContentPane().add(textArea);*/
		
		/*frtable = new JTable();
		//frtable.setBounds(86, 195, 414, 172);
		//frame.getContentPane().add(frtable);
		
		scrollpane1=new JScrollPane(frtable);

		scrollpane1.setBounds(77, 279, 364, 130);
		frame.getContentPane().add(scrollpane1);*/
		
		page_first pr=new page_first();
		String ss[]= new String[3];
		/*int i,j;
		for(i=0;i<3;i++)
		{
			ss[i]=String.valueOf(i);
		}
		//obj=new String[20][20];
		for(i=0;i<20;i++)
		{
			for(j=0;j<3;j++)
			{
				
			}
		}
		
		table = new JTable(pr.bb,ss);*
		 scrollpane=new JScrollPane(table);

		scrollpane.setBounds(77, 279, 364, 130);
		frame.getContentPane().add(scrollpane);*/
	}
}