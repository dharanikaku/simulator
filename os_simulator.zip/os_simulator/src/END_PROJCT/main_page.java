package END_PROJCT;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import java.awt.event.KeyEvent;

import java.awt.event.ActionEvent;

public class main_page implements ActionListener,FocusListener{

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main_page window = new main_page();
					window.frame.setVisible(true);
					
	
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	 void quit() {
		    if (JOptionPane.showConfirmDialog(
		      frame,
		      "Are you sure you want to exit?",
		      "Please confirm",
		      JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION
		    ) {
		      System.exit(0);
		    }
		  }

	/**
	 * Create the application.
	 */
	public main_page() {
		
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame=new JFrame();
		JMenuBar bar=new JMenuBar();
		JMenu file,process,dinning,page,disk,help;
		JMenuItem exiti,homei,processi,dinningi,pagei,diski,helpi;
		
		file=new JMenu("File");
		process=new JMenu("Process");
		dinning=new JMenu("Dinning");
		page=new JMenu("Page");
		disk=new JMenu("Disk");
		help=new JMenu("Help");
		bar.add(file);
		bar.add(process);
		bar.add(dinning);
		bar.add(page);
		bar.add(disk);
		bar.add(help);
		ImageIcon si11=new ImageIcon("/home/indian/Documents/exit.png");
		ImageIcon si12=new ImageIcon("/home/indian/Documents/blue-home-icon.png");
		ImageIcon si4=new ImageIcon("/home/indian/Documents/disk1.png");
		ImageIcon cu=new ImageIcon("rsz_hir_cpu.jpg");
		ImageIcon du=new ImageIcon("rsz_hir_din.jpg");
		ImageIcon pu=new ImageIcon("rsz_page.png");
		exiti=new JMenuItem("Exit",si11);
		
		homei=new JMenuItem("Home",si12);
		homei.setMnemonic(KeyEvent.VK_H);
		processi=new JMenuItem("CPU Scheduling",cu);
		dinningi=new JMenuItem("Dinning Philosophers",du);
		pagei=new JMenuItem("Page Replacement",pu);
		diski=new JMenuItem("Disk Management",si4);
		helpi=new JMenuItem("Help");
		file.add(exiti);
		file.add(homei);
		process.add(processi);
		dinning.add(dinningi);
		page.add(pagei);
		disk.add(diski);
		diski.setMnemonic(KeyEvent.VK_D);
		help.add(helpi);
		frame.setJMenuBar(bar);
		JButton bt=new JButton("a");
		bt.setSize(100,100);
		bt.setVisible(true);
		 JLabel lb1=new JLabel();
		 frame.getContentPane().add(lb1);
		 frame.addFocusListener(this);
		 frame.setFocusable(true);
		 lb1.setVisible(false);
		frame.setBounds(100, 100, 600, 600);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		ImageIcon img1=new ImageIcon("/home/indian/Documents/rsz_cpu.jpg");
		ImageIcon img2=new ImageIcon("/home/indian/Documents/rsz_dine.jpg");
		ImageIcon img3=new ImageIcon("/home/indian/Documents/rsz_page.png");
		ImageIcon img4=new ImageIcon("/home/indian/Documents/rsz_disk2.png");
		JButton btcpu = new JButton(img1);
		
		btcpu.setToolTipText("CPU schdueling");
		btcpu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				a_start c=new a_start();
				c.req();
			}
		});
		btcpu.setBounds(119, 56, 150, 150);
		frame.getContentPane().add(btcpu);
		
		JButton btdine = new JButton(img2);
		btdine.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				edited d=new edited();
				d.req();
			}
		});
		btdine.setToolTipText("Dinning Philosophers");
		btdine.setBounds(281, 56, 150, 150);
		frame.getContentPane().add(btdine);
		
		JButton btpage = new JButton(img3);
		btpage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				page_first p=new page_first();
				p.req();
				
			}
		});
		btpage.setToolTipText("Page Replacement");
		btpage.setBounds(119, 218, 150, 150);
		frame.getContentPane().add(btpage);
		
		JButton btdisk = new JButton(img4);
		btdisk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				disk_first ds=new disk_first();
				ds.req();
			}
			
		});
		btdisk.setToolTipText("Disk Management");
		btdisk.setBounds(281, 218, 150, 150);
		frame.getContentPane().add(btdisk);
		exiti.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						quit();
					}
				});
		
		diski.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						disk_first ds1=new disk_first();
						ds1.req();
					}
				});
		processi.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				a_start a1=new a_start();
				a1.req();
			}
		});
		dinningi.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				edited z=new edited();
				z.req();
			}
		});
		pagei.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				page_first pf=new page_first();
				pf.req();
			}
		});
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void keyPressed(KeyEvent e) {
		if(e.getKeyChar()=='X')
			System.exit(0);
		if(e.getKeyChar()=='D')
		{
			//disk ds=new disk();
			//ds.req();
		}
		if(e.getKeyChar()=='H')
		{
			//disk ds=new disk();
			//ds.req();
		}
		
		// TODO Auto-generated method stub
		
	}

	public void keyReleased(KeyEvent e) {
		
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		
	}

	

}
